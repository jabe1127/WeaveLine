--[[ WeaveLine ------------------------------------------------------------
  Two-track shot timing for TBC hunters.

  PLAN (bottom) is free-running. Its phase is set once and then advances
  by its own simulation, so it never snaps to your real shots -- drift
  between the lanes is the signal that you are off rotation.

  Placement is by PRIORITY, not by a fixed five-step template:
      Multi-Shot if it is off cooldown at the moment the GCD frees
      else Arcane Shot if it is off cooldown
      else nothing -- Steady and auto only, which is a weave cycle
  Because a cooldown ticks down at the same rate the bar scrolls, a
  placement decided this way sits still on screen. The old step counter
  re-derived on every auto, which is what made it jump.

  ACTUAL (top) is what you really cast.

    red     auto shot        yellow  Steady casting
    orange  GCD gap          violet  Multi-Shot      pink  Arcane Shot

  Timing ported from Bouk's Hunter Castbar: cast = tooltip / haste,
  haste includes quiver, auto = reload(eWS - 0.5/haste) then a hasted
  0.5s cast. The auto is blocked by casts only, never by the GCD.

  v2.1
--------------------------------------------------------------------------]]

local CONFIG = {
  width       = 475,
  laneH       = 17,
  laneGap     = 5,
  pad         = 0,
  border      = 2,          -- outline thickness
  textGap     = 7,          -- clearance between text and the border

  impactMelee = 0.50,       -- punch duration for a plain melee swing
  impactRaptor= 0.80,       -- Raptor gets a longer, bigger one
  impactBlinks= 3,          -- pulses of grey/white inside that window
  impactScale = 0.10,       -- peak expansion; the main tactile cue
  impactPeak  = 0.90,       -- flash alpha at the instant of the hit
  impactPop   = 5,          -- extra border px at peak

  -- The top lane is a MOVEMENT window, not a timeline. Three states,
  -- each a fact: rooted while casting, free while not, hold still while
  -- the auto animates. Nothing is predicted so nothing can desync.
  weaveBar    = true,

  -- A finished cast stays on the bar this long. Multi is ~362ms hasted,
  -- which is easy to miss entirely, so the confirmation that it went out
  -- matters more than the cast bar itself.
  castHold    = 0.35,

  -- Past this the exact number stops mattering -- you are simply very
  -- late -- so it caps and shows a + instead of a running total.
  lateCap     = 3.0,

  -- Neither lane scrolls any more -- both are fills -- so there is no
  -- "now" position to mark and no content sliding off an edge.
  nowLine     = false,

  -- Each state fills the whole bar and drains over its own duration.
  -- Off, they share one cycle-length scale instead: widths then show
  -- relative duration and everything drains at the same rate, but the
  -- short states only ever use a sliver of the bar.
  fullBar     = true,

  meleeLane   = true,

  -- Slack meter. One quantity: how long before starting a Steady would
  -- clip. Computed from your last real auto and the live GCD, so there
  -- is nothing predicted and nothing to desync.
  slackMeter  = false,
  slackH      = 14,
  slackGap    = 6,    -- second lane inside the border, same height
  idleAlpha   = 0.10,    -- out of combat but on an enemy target
  neverFade   = false,   -- always fully visible; overrides every fade rule

  -- Skins are DATA, not code: tables of CONFIG and C values written in
  -- and followed by layout(). No new frames, no new draw paths, nothing
  -- structural -- which is why they cannot break the timing logic.
  skin        = "Default",
  fontFace    = "Default",
  fontSize    = 12,     -- the state label on the bar
  rangeSize   = 12,     -- range readout, top left
  ewsSize     = 12,     -- eWS readout, bottom left
  clipSize    = 12,     -- clip / clean, top right

  -- Where each readout sits, as one of the 8 anchor points around the
  -- bar. Purely positional data -- layout() already does the SetPoint.
  posEws      = "BOTTOMLEFT",
  posClip     = "TOPRIGHT",
  posRange    = "TOPLEFT",
  -- Off: the readouts sit at one of the 8 anchors around the bar.
  -- On: each becomes its own draggable frame, like the icons.
  freeText    = false,
  hideNoTarget= true,
  noTargetFade= 2.0,        -- seconds without a hostile target before fading

  cycles      = 3.0,
  linePos     = 0.22,

  lineWidth   = 3,
  gcd         = 1.5,
  arcaneWidth = 0.12,
  -- "french" = the doc's fixed 5:5:1:1 (multi on step 1, arcane on step 3).
  -- "priority" = fire each instant whenever its cooldown is up, which
  -- over-fires Arcane relative to the doc. French is the correct default.
  -- Bouk's Duration Info multiplies ranged haste in twice. It reads like
  -- a slip, but his bar is the one that visibly tracks the shots, so
  -- match it by default. /wl squarehaste flips to the plain reading.
  squareHaste = false,
  separators  = true,    -- leading-edge bar at each press moment
  sepWidth    = 3,
  sepBright   = 0.55,    -- how far the separator lightens toward white
  sepOverhang = 0,       -- px the separator extends past the lane, each end

  -- Melee swing timer: a thin fill along the bottom edge. Swing timing
  -- is continuous rather than scheduled, so it does not belong on the
  -- scrolling track.
  -- Marks where the cast currently in flight will finish, so you can see
  -- it against the upcoming auto without a separate cast bar.
  -- Multi and Arcane live outside the bar as ready-pips. Fewer moving
  -- parts on the timeline, and cooldowns are continuous state anyway.
  pips        = true,
  pipSize     = 24,
  pipScale    = 1.0,     -- independent of the bar's scale
  showMulti   = true,
  showArcane  = true,
  showKC      = true,
  kcGlow      = 1.0,     -- how hard the Kill Command glow pushes
  pipBorder   = true,
  pipBorderSz = 2,

  -- What the border reports: "off", "range", or "kc".
  borderMode  = "kc",
  pipGap      = 6,
  pipPop      = 0.35,    -- swell when an instant comes off cooldown
  pipCastPop  = 0.55,    -- and a bigger one when it actually goes out
  pipCastGrow = 0.75,    -- how far it swells on cast
  pipLift     = 5,       -- clearance above the border
  pipGlow     = true,

  castTick    = true,
  castTickW   = 3,
  -- Draw the cast actually in flight over the plan. Any part of it
  -- running past where the plan wanted the Steady to end is drawn red:
  -- that overhang is the clip, visible while it happens instead of
  -- being silently absorbed by the phase correction afterwards.
  castBar     = true,

  -- A weave is a round trip, and travel eats most of the window. A swing
  -- only counts if you can reach melee before it lands AND get back out
  -- before the auto. Marks are coloured by that test.
  markReach   = true,
  runSpeed    = 7.0,     -- fallback yd/s when GetUnitSpeed is unavailable
  meleeRange  = 5.0,

  -- Distance estimator. The probes are not brackets -- each one is an
  -- EXACT crossing: the instant the 7yd item flips true you are at 7.0
  -- yards. Between crossings we integrate movement speed, and the
  -- bracket clamps the result, so error can never exceed the gap between
  -- two rungs and is usually far smaller.
  estimate    = true,
  showRange   = true,    -- range readout + coloured border
  showEws     = true,    -- eWS figure bottom-left
  showClip    = true,    -- clip / clean readout top-right
  uiScale     = 1.0,
  probeHz     = 20,
  -- Integration is only trusted for this long after an exact crossing.
  -- Past it the estimate eases toward the middle of its bracket, because
  -- dead reckoning with no fix drifts to an edge and reports a precise
  -- number that is simply wrong. Decaying to the bracket keeps it honest.
  fixTrust    = 0.8,
  fixDecay    = 1.5,
  swingStale  = 2.2,     -- hide after this many swing periods with no hit

  -- "tail"   idle drawn as a dim continuation of whatever caused it
  -- "block"  idle drawn as its own solid colour
  -- "hidden" idle not drawn at all
  idleStyle   = "block",
  idleTailAlpha = 0.30,
  -- Gaps shorter than this are absorbed into the segment that follows.
  -- The GCD from an instant spills ~112ms past the next auto, which is
  -- too short to act on and sits exactly where you look for the Steady.
  idleMin     = 0.16,
  ticks       = false,

  -- Only the next auto shot is actually known: it is lastAuto + eWS.
  -- Everything past it is a guess about shots you have not taken, and
  -- revising a guess that was drawn as fact is what the jumping was.
  -- Beyond that point the bar is drawn faded, so a revision reads as
  -- "that was always speculative" instead of as a glitch.
  -- Speculation is RECESSED, not hidden. Lookahead is the point of the
  -- bar; dropping it to 22% removed the information it exists to show.
  -- This only needs to be enough that a revision out there reads as
  -- "that was a guess" rather than as the bar glitching.
  -- Confidence fades CONTINUOUSLY with distance rather than stepping at
  -- the next auto. A hard boundary jumped a full cycle every time a shot
  -- landed, flipping a whole stretch of bar from faded to solid in one
  -- frame -- that was the jitter after each auto.
  ghostAlpha  = 0.78,   -- alpha at the far end of the lookahead
  horizonMark = false,  -- the marker steps too, so off by default

  -- Phase lock. Notes are generated from ideal timing, but real autos
  -- clip, so the schedule drifts ahead of reality. Rather than rebuild
  -- notes (which made the bar jump), the whole track is slid by a
  -- correction that bleeds in at a capped fraction of scroll speed --
  -- enough to be invisible, fast enough to stay locked.
  -- Hold the timeline at each auto shot until the real one fires. A
  -- clip becomes a visible stall whose length is exactly how late you
  -- were, instead of drift you never see. Handles reality being LATE;
  -- the slew below still handles reality being early.
  -- OFF by default. Holding the timeline at each auto made clipping
  -- visible, but a bar that stops reads as a bug to anyone using it --
  -- "gets stuck mid rotation" is exactly what it looks like. /wl gate
  -- re-enables it.
  -- The bar waits at each auto until your real shot lands. A continuous
  -- bar cannot stay in sync with a variable-rate event -- it can drift,
  -- jitter, or wait, and waiting is the only one that is not a lie.
  --
  -- The stop is RIGID. Easing into it fed the ramp off the same clock
  -- the ramp was slowing, which is a feedback loop that can settle
  -- anywhere. Full speed, then stopped, then full speed again.
  gateOnAuto  = true,
  gateMax     = 1.5,     -- seconds; never stall longer than this

  -- Active whenever the gate is off. Slides the whole track to match
  -- your real autos, converging smoothly instead of stopping.
  phaseLock   = true,
  -- Ignore corrections under this. Event timing carries a few ms of
  -- latency and frame-boundary noise, so the measured error flips sign
  -- around zero -- applying each one nudges the bar backward as often as
  -- forward. Real drift is far larger than the noise floor.
  phaseDead   = 0.045,

  -- Segments fade out over this many pixels at each edge rather than
  -- vanishing. Matters most at high haste, where the bar scrolls fast
  -- enough that popping is obvious.
  edgeFade    = 0,

  -- Fraction of each auto's error that is applied. Correcting in full
  -- meant the plan ADOPTED your timing: a 200ms clip moved the whole
  -- reference 200ms, so the next cast had nothing to be late against and
  -- the bar showed no error. It also jumped 8-16px on nearly every shot,
  -- because a real player's error is reaction time, not noise.
  --
  -- At 0.12 a single clip moves the bar under a pixel and stays visible
  -- as a gap; a sustained drift is still ~78% tracked after a dozen
  -- autos. The plan stays a metronome you can be wrong against.
  -- With the grid running at your MEASURED rhythm there is no systematic
  -- error left, so phase only has to absorb noise and a firmer gain is
  -- safe. At 0.12 with a fixed eWS grid the offset parked near half a
  -- cycle, right on the wrap boundary, and the correction flipped sign
  -- every shot -- that was the jumping.
  phaseGain   = 0.25,

  -- The correction is BLED IN over time, never applied in one frame.
  -- Normal motion is ~0.88px per frame, so even a half-pixel step lands
  -- as a visible hitch. Capped at a small fraction of scroll speed, the
  -- motion goes from 0.88 to 0.90 px/frame -- nothing to see.
  bleedMax    = 0.03,

  -- How fast the grid learns your real auto-to-auto interval. Your
  -- actual rhythm is eWS plus whatever you habitually clip; assuming a
  -- perfect eWS guarantees a growing offset.
  cycleGain   = 0.15,

  -- Phase is aligned on every auto, immediately. No easing, no stalling.
  -- A guide is a metronome you compare yourself against; smoothing meant
  -- the bar got dragged around by your own mistakes and stopped being a
  -- reference. With the auto grid correct the per-shot error is small,
  -- so instant alignment is the least intrusive option as well as the
  -- most honest one.
  gloss       = true,

  -- Idle fills its slot like any other segment. Drawing it short left a
  -- thin bar running through the centre of the whole bar, which read as
  -- an artifact rather than as information.
  idleHeight  = 1.00,     -- fraction of lane height; 1 = full block
  showIdle    = true,

  -- Second melee probe: inside 10 yards while Auto Shot reports out of
  -- range means you are inside its minimum, i.e. melee. Backs up Wing
  -- Clip in case that check lags.
  meleeUseAutoShot = true,

  debug       = false,
}

local C = {
  panel   = { 0.045, 0.050, 0.065, 0.96 },
  track   = { 0.100, 0.110, 0.135, 1.00 },
  sheen   = { 1.000, 1.000, 1.000, 0.07 },
  sep     = { 0.000, 0.000, 0.000, 1.00 },
  swingUp = { 0.130, 0.72, 0.24, 1.00 },   -- Raptor ready
  swingCd = { 0.520, 0.54, 0.60, 1.00 },   -- Raptor on cooldown
  pipEdge = { 0.000, 0.00, 0.00, 0.90 },   -- outline around each icon
  swingBg = { 0.120, 0.13, 0.15, 0.90 },
  castEnd = { 0.400, 0.95, 1.00, 1.00 },
  slkOpen = { 0.250, 0.90, 0.30, 1.00 },   -- window open, press
  slkLock = { 0.380, 0.42, 0.55, 1.00 },   -- GCD locked, nothing to do
  slkNone = { 0.700, 0.16, 0.16, 1.00 },   -- no clean window this cycle
  slkLate = { 0.950, 0.35, 0.10, 1.00 },   -- past the deadline
  slkBack = { 0.090, 0.10, 0.13, 1.00 },
  mvFree  = { 0.220, 0.85, 0.35, 1.00 },   -- free to move
  mvCast  = { 0.400, 0.44, 0.55, 1.00 },   -- rooted, casting
  mvHold  = { 0.880, 0.22, 0.20, 1.00 },   -- auto animating, stand still
  mvOver  = { 0.950, 0.45, 0.10, 1.00 },   -- this cast will clip the auto
  mvChan  = { 0.250, 0.55, 0.70, 1.00 },   -- channelling
  mvLate  = { 1.000, 0.70, 0.10, 1.00 },   -- auto is overdue and waiting
  mvDone  = { 0.620, 0.66, 0.78, 1.00 },   -- that cast just went out
  mvWait  = { 0.300, 0.33, 0.40, 1.00 },   -- free, but no swing lands in time
  mvCue   = { 0.950, 0.78, 0.15, 1.00 },   -- cast Steady, now
  mvBack  = { 0.080, 0.09, 0.11, 1.00 },
  slkDone = { 0.180, 0.34, 0.28, 1.00 },   -- already cast; nothing to do
  horizon = { 1.000, 1.00, 1.00, 0.30 },
  castRun = { 1.000, 0.98, 0.98, 0.55 },   -- your cast, on plan
  castOver= { 1.000, 0.20, 0.18, 0.85 },   -- the part running late
  pipOff  = { 0.130, 0.14, 0.17, 1.00 },
  pipLit  = { 1.000, 0.92, 0.45, 0.85 },
  kcLit   = { 1.000, 0.55, 0.05, 1.00 },   -- Kill Command, hard to miss
  kcEdge  = { 1.000, 0.55, 0.05, 1.00 },   -- border when KC is castable
  txtState= { 1.000, 1.00, 1.00, 1.00 },
  txtEws  = { 0.604, 0.627, 0.690, 1.00 },
  txtRange= { 0.700, 0.760, 0.860, 1.00 },
  txtClip = { 0.373, 0.851, 0.498, 1.00 },
  reach   = { 0.400, 1.00, 0.35, 1.00 },   -- swing you can actually make
  noReach = { 0.700, 0.72, 0.78, 1.00 },   -- swing you cannot get to
  edge    = { 0.015, 0.015, 0.022, 1.00 },
  hairline= { 1.000, 1.000, 1.000, 0.05 },

  auto    = { 0.82, 0.23, 0.26 },
  steady  = { 0.95, 0.74, 0.22 },
  down    = { 1.00, 0.55, 0.12 },   -- orange: downtime / GCD gap
  weave   = { 1.00, 0.55, 0.12 },
  multi   = { 0.58, 0.36, 0.90 },
  arcane  = { 0.96, 0.34, 0.70 },

  tick    = { 1.00, 1.00, 1.00, 0.30 },

  -- Border by range to target.
  rngFar    = { 0.90, 0.15, 0.15, 1.00 },   -- out of shooting range
  rngRanged = { 0.20, 0.45, 0.95, 1.00 },   -- ~10 to 35 yards
  rngStep   = { 0.20, 1.00, 0.25, 1.00 },   -- one tap of W from melee
  rngMelee  = { 1.00, 0.95, 0.10, 1.00 },   -- in melee
  impact    = { 1.00, 1.00, 1.00, 1.00 },
  line    = { 1.00, 1.00, 1.00 },   -- white: distinct from yellow steady and red auto
  dim     = { 0.55, 0.57, 0.65 },
}

--------------------------------------------------------------------------
-- Shims
--------------------------------------------------------------------------

local function spellInfo(x)
  if C_Spell and C_Spell.GetSpellInfo then
    local t = C_Spell.GetSpellInfo(x)
    if t then return t.name, t.iconID, (t.castTime or 0) end
  end
  local n, _, i, ct = GetSpellInfo(x)
  return n, i, ct or 0
end

local function spellCD(x)
  if C_Spell and C_Spell.GetSpellCooldown then
    local c = C_Spell.GetSpellCooldown(x)
    if c then return c.startTime or 0, c.duration or 0 end
  end
  local s, d = GetSpellCooldown(x)
  return s or 0, d or 0
end

local function bagName(i)
  if C_Container and C_Container.GetBagName then return C_Container.GetBagName(i) end
  if GetBagName then return GetBagName(i) end
end

-- Flat fill with a vertical gloss. No texture art: it made the bar
-- busy without making segments easier to tell apart.
local function paint(tex, c, alpha)
  local r, g, b = c[1], c[2], c[3]
  tex:SetColorTexture(r, g, b, alpha)
  if CONFIG.gloss and tex.SetGradient and CreateColor then
    pcall(function()
      tex:SetGradient("VERTICAL",
        CreateColor(r * 0.52, g * 0.52, b * 0.52, alpha),
        CreateColor(math.min(1, r * 1.22), math.min(1, g * 1.22), math.min(1, b * 1.22), alpha))
    end)
  end
end

--------------------------------------------------------------------------
-- Haste (GetRangedHaste omits quiver)
--------------------------------------------------------------------------

local QUIVER = {}
do
  local map = {
    [1.15] = {18714,19320,19319,29118,34106,29143,29144,34100,34099},
    [1.14] = {2663,2662},  [1.13] = {7372,7371},
    [1.12] = {8218,8217},  [1.11] = {3604,3605},
    [1.10] = {2101,5439,7278,11362,3574,5441,7279,11363,2102},
  }
  for h, ids in pairs(map) do for _, id in ipairs(ids) do QUIVER[id] = h end end
end

local function haste()
  local h = 1 + ((GetRangedHaste and GetRangedHaste() or 0) / 100)
  for i = 1, 4 do
    local nm = bagName(i)
    if nm then
      local id = GetItemInfoInstant and GetItemInfoInstant(nm)
      if id and QUIVER[id] then return h * QUIVER[id] end
    end
  end
  return h
end

--------------------------------------------------------------------------
-- Spells and timings
--------------------------------------------------------------------------

local SPELL, ICON, SPELLID = {}, {}, {}

--------------------------------------------------------------------------
-- Anchors
--
-- Each entry: the point ON the label, the point ON the bar it attaches
-- to, and the x/y nudge. Above the bar attaches to a TOP* point, below
-- to a BOTTOM*; the sign of the gap flips accordingly.
--------------------------------------------------------------------------

local ANCHORS = {
  TOPLEFT     = { "BOTTOMLEFT",  "TOPLEFT",       2,  1 },
  TOP         = { "BOTTOM",      "TOP",           0,  1 },
  TOPRIGHT    = { "BOTTOMRIGHT", "TOPRIGHT",     -2,  1 },
  LEFT        = { "RIGHT",       "LEFT",         -6,  0 },
  RIGHT       = { "LEFT",        "RIGHT",         6,  0 },
  BOTTOMLEFT  = { "TOPLEFT",     "BOTTOMLEFT",    2, -1 },
  BOTTOM      = { "TOP",         "BOTTOM",        0, -1 },
  BOTTOMRIGHT = { "TOPRIGHT",    "BOTTOMRIGHT",  -2, -1 },
}
local ANCHOR_ORDER = {
  "TOPLEFT", "TOP", "TOPRIGHT", "LEFT",
  "RIGHT", "BOTTOMLEFT", "BOTTOM", "BOTTOMRIGHT",
}

--------------------------------------------------------------------------
-- Skins
--------------------------------------------------------------------------

local SKINS = {
  { name = "Default", cfg = {}, col = {} },

  { name = "Muted",
    cfg = { border = 2, laneH = 17 },
    col = {
      mvCast  = { 0.42, 0.45, 0.52 },  mvFree = { 0.36, 0.60, 0.42 },
      mvHold  = { 0.62, 0.32, 0.32 },  mvWait = { 0.30, 0.32, 0.38 },
      mvOver  = { 0.68, 0.48, 0.30 },  mvLate = { 0.66, 0.55, 0.32 },
      mvChan  = { 0.34, 0.48, 0.56 },  mvDone = { 0.44, 0.47, 0.54 },
      swingUp = { 0.28, 0.52, 0.34 },  swingCd = { 0.34, 0.36, 0.40 },
      track   = { 0.11, 0.12, 0.14 },  mvBack  = { 0.10, 0.11, 0.13 },
    } },

  { name = "High contrast",
    cfg = { border = 4, laneH = 20 },
    col = {
      mvCast  = { 1.00, 0.82, 0.10 },  mvFree = { 0.10, 1.00, 0.25 },
      mvHold  = { 1.00, 0.10, 0.10 },  mvWait = { 0.38, 0.40, 0.48 },
      mvOver  = { 1.00, 0.45, 0.00 },  mvLate = { 1.00, 0.70, 0.00 },
      mvChan  = { 0.15, 0.70, 1.00 },  mvDone = { 0.80, 0.84, 0.92 },
      swingUp = { 0.10, 1.00, 0.25 },  swingCd = { 0.55, 0.57, 0.62 },
      track   = { 0.03, 0.03, 0.04 },  mvBack  = { 0.03, 0.03, 0.04 },
    } },

  { name = "Minimal",
    cfg = { border = 0, laneH = 12, textGap = 4 },
    col = {
      mvCast  = { 0.70, 0.72, 0.78 },  mvFree = { 0.40, 0.78, 0.50 },
      mvHold  = { 0.78, 0.34, 0.34 },  mvWait = { 0.26, 0.28, 0.32 },
      mvOver  = { 0.85, 0.52, 0.25 },  mvLate = { 0.85, 0.66, 0.25 },
      mvChan  = { 0.40, 0.60, 0.72 },  mvDone = { 0.52, 0.55, 0.62 },
      swingUp = { 0.35, 0.70, 0.42 },  swingCd = { 0.30, 0.32, 0.36 },
      track   = { 0.07, 0.07, 0.09 },  mvBack  = { 0.06, 0.06, 0.08 },
    } },

  { name = "Slim",
    cfg = { border = 1, laneH = 10, laneGap = 1, textGap = 3, pad = 0 },
    col = {
      mvCast  = { 0.90, 0.74, 0.16 },  mvFree = { 0.20, 0.86, 0.36 },
      mvHold  = { 0.90, 0.20, 0.20 },  mvWait = { 0.22, 0.24, 0.28 },
      mvOver  = { 0.95, 0.45, 0.10 },  mvLate = { 0.95, 0.66, 0.12 },
      mvChan  = { 0.22, 0.56, 0.72 },  mvDone = { 0.46, 0.49, 0.56 },
      swingUp = { 0.20, 0.80, 0.32 },  swingCd = { 0.26, 0.28, 0.32 },
      track   = { 0.05, 0.05, 0.07 },  mvBack  = { 0.05, 0.05, 0.07 },
    } },

  { name = "Chunky",
    cfg = { border = 5, laneH = 26, laneGap = 4, textGap = 9 },
    col = {
      mvCast  = { 1.00, 0.78, 0.14 },  mvFree = { 0.14, 0.92, 0.30 },
      mvHold  = { 0.96, 0.16, 0.16 },  mvWait = { 0.30, 0.32, 0.38 },
      mvOver  = { 1.00, 0.48, 0.06 },  mvLate = { 1.00, 0.72, 0.08 },
      mvChan  = { 0.18, 0.62, 0.84 },  mvDone = { 0.62, 0.66, 0.76 },
      swingUp = { 0.14, 0.88, 0.28 },  swingCd = { 0.44, 0.46, 0.52 },
      track   = { 0.06, 0.06, 0.08 },  mvBack  = { 0.05, 0.05, 0.07 },
    } },

  { name = "Amber",
    cfg = { border = 2, laneH = 18, textGap = 6 },
    col = {
      mvCast  = { 0.98, 0.72, 0.22 },  mvFree = { 0.86, 0.56, 0.12 },
      mvHold  = { 0.72, 0.24, 0.10 },  mvWait = { 0.26, 0.22, 0.18 },
      mvOver  = { 0.95, 0.40, 0.08 },  mvLate = { 1.00, 0.60, 0.10 },
      mvChan  = { 0.60, 0.44, 0.16 },  mvDone = { 0.52, 0.45, 0.34 },
      swingUp = { 0.90, 0.66, 0.18 },  swingCd = { 0.32, 0.29, 0.24 },
      track   = { 0.08, 0.06, 0.04 },  mvBack  = { 0.07, 0.05, 0.03 },
    } },

  { name = "Ice",
    cfg = { border = 2, laneH = 16, textGap = 6 },
    col = {
      mvCast  = { 0.55, 0.82, 1.00 },  mvFree = { 0.30, 0.92, 0.86 },
      mvHold  = { 0.32, 0.44, 0.88 },  mvWait = { 0.20, 0.26, 0.34 },
      mvOver  = { 0.70, 0.60, 1.00 },  mvLate = { 0.50, 0.70, 1.00 },
      mvChan  = { 0.36, 0.70, 0.94 },  mvDone = { 0.50, 0.58, 0.70 },
      swingUp = { 0.34, 0.90, 0.84 },  swingCd = { 0.26, 0.30, 0.38 },
      track   = { 0.04, 0.06, 0.09 },  mvBack  = { 0.03, 0.05, 0.08 },
    } },

  { name = "Mono",
    cfg = { border = 1, laneH = 15, textGap = 5 },
    col = {
      mvCast  = { 0.86, 0.87, 0.90 },  mvFree = { 0.62, 0.64, 0.68 },
      mvHold  = { 0.34, 0.35, 0.38 },  mvWait = { 0.20, 0.21, 0.23 },
      mvOver  = { 1.00, 1.00, 1.00 },  mvLate = { 0.74, 0.75, 0.78 },
      mvChan  = { 0.48, 0.50, 0.54 },  mvDone = { 0.40, 0.42, 0.46 },
      swingUp = { 0.80, 0.82, 0.86 },  swingCd = { 0.26, 0.27, 0.30 },
      track   = { 0.06, 0.06, 0.07 },  mvBack  = { 0.05, 0.05, 0.06 },
    } },

  { name = "Dark",
    cfg = { border = 2, laneH = 18 },
    col = {
      mvCast  = { 0.80, 0.66, 0.20 },  mvFree = { 0.20, 0.70, 0.34 },
      mvHold  = { 0.72, 0.18, 0.18 },  mvWait = { 0.18, 0.19, 0.22 },
      mvOver  = { 0.82, 0.40, 0.12 },  mvLate = { 0.85, 0.58, 0.10 },
      mvChan  = { 0.20, 0.44, 0.58 },  mvDone = { 0.34, 0.36, 0.42 },
      swingUp = { 0.16, 0.58, 0.26 },  swingCd = { 0.24, 0.25, 0.29 },
      track   = { 0.02, 0.02, 0.03 },  mvBack  = { 0.02, 0.02, 0.03 },
    } },
}

-- Each entry lists candidate paths, tried in order until one loads.
-- Non-stock fonts live inside other addons, and the folder moved between
-- ElvUI versions, so several spellings are offered rather than assuming.
local FONTS = {
  { name = "Default",  paths = {} },
  { name = "Friz",     paths = { "Fonts\\FRIZQT__.TTF" } },
  { name = "Arial",    paths = { "Fonts\\ARIALN.TTF" } },
  { name = "Skurri",   paths = { "Fonts\\SKURRI.TTF" } },
  { name = "Morpheus", paths = { "Fonts\\MORPHEUS.TTF" } },
  { name = "Expressway", paths = {
      "Interface\\AddOns\\ElvUI\\Core\\Media\\Fonts\\Expressway.ttf",
      "Interface\\AddOns\\ElvUI\\Media\\Fonts\\Expressway.ttf",
      "Interface\\AddOns\\SharedMedia\\fonts\\Expressway.ttf",
      "Interface\\AddOns\\SharedMedia_MyMedia\\font\\Expressway.ttf",
      "Interface\\AddOns\\WeaveLine\\Expressway.ttf",
  } },
  { name = "PT Sans", paths = {
      "Interface\\AddOns\\ElvUI\\Core\\Media\\Fonts\\PT_Sans_Narrow.ttf",
      "Interface\\AddOns\\ElvUI\\Media\\Fonts\\PT_Sans_Narrow.ttf",
  } },
  { name = "Homespun", paths = {
      "Interface\\AddOns\\ElvUI\\Core\\Media\\Fonts\\Homespun.ttf",
      "Interface\\AddOns\\ElvUI\\Media\\Fonts\\Homespun.ttf",
  } },
}

-- Captured once so a skin can always be undone without a reload.
local BASE_CFG, BASE_COL = {}, {}
for _, k in ipairs({ "border", "laneH", "textGap", "laneGap", "pad" }) do
  BASE_CFG[k] = CONFIG[k]
end
for k, v in pairs(C) do
  if type(v) == "table" then BASE_COL[k] = { v[1], v[2], v[3], v[4] } end
end

-- LibSharedMedia is the reliable route. ElvUI and most UI packs register
-- their fonts with it by name, so we can ask for "Expressway" instead of
-- guessing where the .ttf lives -- which is what was failing.
local function LSM()
  if not LibStub then return nil end
  local ok, lib = pcall(LibStub, "LibSharedMedia-3.0", true)
  return ok and lib or nil
end

-- Every font name available: LSM's registry if present, plus our own.
local function fontList()
  local out, seen = {}, {}
  local function add(n)
    if n and not seen[n] then seen[n] = true; out[#out+1] = n end
  end
  add("Default")
  local lib = LSM()
  if lib then
    local ok, list = pcall(function() return lib:List("font") end)
    if ok and type(list) == "table" then
      for _, n in ipairs(list) do add(n) end
    end
  end
  for _, f in ipairs(FONTS) do add(f.name) end
  return out
end

local function fontPaths(name)
  -- Ask LSM first; it knows the real path whatever the folder layout.
  local lib = LSM()
  if lib then
    local ok, p = pcall(function() return lib:Fetch("font", name, true) end)
    if ok and type(p) == "string" and p ~= "" then return { p } end
  end
  for _, f in ipairs(FONTS) do
    if f.name == name then return f.paths end
  end
  return nil
end

local function resolve()
  local function grab(id, fname, ficon)
    local name, icon = spellInfo(id)
    return name or fname, icon or ficon
  end
  SPELL.auto,   ICON.auto   = grab(75,    "Auto Shot",     132222)
  SPELL.steady, ICON.steady = grab(34120, "Steady Shot",   132213)
  SPELL.multi,  ICON.multi  = grab(2643,  "Multi-Shot",    132330)
  SPELL.arcane, ICON.arcane = grab(3044,  "Arcane Shot",   132218)
  SPELL.raptor, ICON.raptor = grab(2973,  "Raptor Strike", 132223)
  SPELL.kc,     ICON.kc     = grab(34026, "Kill Command",  132176)

  -- Cooldowns are looked up by ID: C_Spell.GetSpellCooldown wants a
  -- numeric spellID and returns nothing usable for a name.
  SPELLID.auto,   SPELLID.steady = 75,    34120
  SPELLID.multi,  SPELLID.arcane = 2643,  3044
  SPELLID.raptor, SPELLID.kc     = 2973,  34026
end

local function ews() return (UnitRangedDamage("player")) or 0 end

local function castOf(x)
  local _, _, ct = spellInfo(x)
  return math.max(ct or 0, 500) / 1000 / haste()
end

local function steadyCast() return castOf(SPELL.steady) end
local function multiCast()  return castOf(SPELL.multi)  end

local function autoCast()
  local h = haste()
  if CONFIG.squareHaste then
    h = h * (1 + ((GetRangedHaste and GetRangedHaste() or 0) / 100))
  end
  return 0.5 / h
end

-- Endpoint of the cast in flight, in GetTime() seconds, or nil.
-- Anything you are casting OR channelling, whatever it is. Volley and
-- Rapid Fire are channels and do not appear in UnitCastingInfo at all,
-- so both APIs have to be checked or those simply never show up.
--
-- Returns: start, finish, name, icon, isChannel
local function castWindow()
  local f = UnitCastingInfo
  if f then
    local name, _, tex, startMS, endMS = f("player")
    if name and endMS then
      return (startMS or endMS) / 1000, endMS / 1000, name, tex, false
    end
  end
  local g = UnitChannelInfo
  if g then
    local name, _, tex, startMS, endMS = g("player")
    if name and endMS then
      return (startMS or endMS) / 1000, endMS / 1000, name, tex, true
    end
  end
  return nil
end

local function castEndsAt()
  local _, e = castWindow()
  return e
end

local function meleeSpeed()
  local mh = UnitAttackSpeed("player")
  return (mh and mh > 0) and mh or 2.0
end

local function reload()
  local r = ews() - autoCast()
  return r > 0 and r or 0
end

-- The spell's OWN cooldown, with the GCD filtered out. GetSpellCooldown
-- reports the GCD through every spell while it is running, so a naive
-- read shows ~1.5s on Multi and Arcane after any input, whether or not
-- they are actually on cooldown. Multi is 10s and Arcane 6s, so anything
-- GCD-length is not theirs.
-- Kill Command is gated by a pet-crit proc as well as its cooldown, so a
-- cooldown check alone never lights it. IsUsableSpell covers both.
local function spellUsable(id)
  if C_Spell and C_Spell.IsSpellUsable then
    local ok, u = pcall(C_Spell.IsSpellUsable, id)
    if ok then return u and true or false end
  end
  if IsUsableSpell then
    local ok, u = pcall(IsUsableSpell, id)
    if ok then return u and true or false end
  end
  return false
end

local function realCdLeft(name)
  if not name then return 0 end
  local st, dur = spellCD(name)
  if not st or st == 0 then return 0 end
  if dur <= CONFIG.gcd + 0.05 then return 0 end
  local r = (st + dur) - GetTime()
  return r > 0 and r or 0
end

local function cdLeft(name)
  local s, d = spellCD(name)
  if not s or s == 0 then return 0 end
  local r = (s + d) - GetTime()
  return r > 0 and r or 0
end

--------------------------------------------------------------------------
-- State
--------------------------------------------------------------------------

local state = {
  lastAuto = 0,
  plan     = {},      -- committed notes; never rewritten once placed
  actual   = {},
  lastClip = 0,

  lastPhaseErr = 0,
  cycleLen     = nil,   -- measured auto-to-auto interval
  skipInterval = false, -- next interval spans a break; do not measure it
  castEndAt    = 0,     -- when the last cast finished
  castEndName  = nil,
  castEndIcon  = nil,
  pending      = 0,     -- correction still to be bled in

  dist      = nil,    -- estimated yards to target
  moveDir   = 0,      -- -1 closing, +1 opening, 0 unknown
  probeLo   = 0,
  probeHi   = 99,
  probeAt   = 0,
  fixAt     = 0,
  lastSwing    = 0,

  hold         = 0,      -- CURRENT stall only; reset to 0 on release
  holding      = false,
  stallStarted = false,
  gate         = nil,    -- plan time of the auto we are waiting on
  gatePassed   = 0,
  lastStall    = 0,

  impactAt     = 0,
  impactDur    = 0.2,
  impactStrong = false,
}

local function pushActual(kind, t0, t1)
  state.actual[#state.actual + 1] = { kind = kind, t0 = t0, t1 = t1 }
  if #state.actual > 60 then table.remove(state.actual, 1) end
end

--------------------------------------------------------------------------
-- Plan: a committed note queue.
--
-- Notes are generated once, ahead of time, and never rewritten. The
-- generator carries its OWN simulated cooldowns forward rather than
-- reading live ones every frame -- reading live cooldowns is what let a
-- Multi cast retroactively move notes that were already on screen.
-- A note, once placed, stays exactly where it is until it scrolls off.
--------------------------------------------------------------------------

local gen = {
  seeded  = false,
  t       = 0,   -- time the next simulated auto lands
  gcdFree = 0,   -- 0..4 through the French sequence
}

-- Rotations keyed to eWS bands from boukx.github.io/rotations. Only the
-- inputs a band actually uses are ever emitted, so at 1:1 no Multi or
-- Arcane notes appear at all.
local ROT = {
  french = {                       -- 5:5:1:1, eWS 2.8 -> 1.8
    name = "French 5:5:1:1", len = 5,
    inst  = { [0] = "multi", [2] = "arcane" },
    weave = { [1] = true, [3] = true },       -- French 2 weave
  },
  fiveSix = {                      -- 5:6:1:1, eWS 1.9 -> 1.7
    name = "5:6:1:1", len = 6,
    inst  = { [0] = "arcane", [1] = "multi" },
    noSteady = { [1] = true },     -- that cycle is auto - multi only
    weave = { [2] = true, [4] = true },
  },
  oneToOne = {                     -- auto - steady, repeat
    name = "1:1", len = 1,
    inst = {}, weave = { [0] = true },        -- raptor on cooldown
  },
}

local function currentRot()
  local e = ews()
  if e >= 1.9 then return ROT.french end
  if e >= 1.7 then return ROT.fiveSix end
  return ROT.oneToOne
end

local function seedGenerator(now)
  gen.seeded  = true
  gen.t       = now
  gen.gcdFree = 0
  state.hold, state.holding = 0, false
  state.gate, state.gatePassed = nil, 0
  state.lastStall = 0
  wipe(state.plan)
end

-- Emit one ideal cycle starting from an auto landing at gen.t.
-- Every interval inside the cycle is covered by exactly one segment --
-- any hole left over is filled with idle, so the track is never blank.
-- One cycle == one weapon swing. Always.
--
-- The auto grid is strictly eWS apart and nothing is allowed to bound
-- it. The Steady is fitted INTO that grid only when the GCD permits.
-- Letting the Steady's GCD bound the cycle broke at high haste: the GCD
-- is a flat 1.5s while the swing can be 0.73s, so the generator emitted
-- one auto per GCD instead of one per swing and dropped ~40% of shots.
--
-- Cycles with no Steady are correct, not a failure -- that is what 1:2
-- and x-1:x look like.
-- The interval the grid actually runs at: your measured rhythm once we
-- have one, falling back to the theoretical eWS until then.
local function cycleLength()
  local e = ews()
  if e <= 0 then return 0 end
  local c = state.cycleLen
  if not c then return e end
  -- Clamped so a bad measurement cannot run away with the grid.
  if c < e * 0.6 then c = e * 0.6 end
  if c > e * 1.8 then c = e * 1.8 end
  return c
end

local function generateCycle()
  local sc, ac = steadyCast(), autoCast()
  local speed  = cycleLength()
  if speed <= 0 then gen.t = gen.t + 0.5 return end

  local t         = gen.t              -- previous auto landed here
  local autoLand  = t + speed          -- next one, on the grid
  local autoStart = autoLand - ac
  local out       = state.plan

  -- Only real events are drawn: a Steady at its true cast length and an
  -- Auto at its true cast length. The space between them is left empty,
  -- so downtime is IMPLIED by the gap rather than asserted as a block.
  -- Drawing it was claiming structure the bar cannot actually know.
  local s0 = math.max(t, gen.gcdFree)

  if (s0 + sc) <= autoStart then
    out[#out+1] = { kind = "steady", t0 = s0, t1 = s0 + sc }
    gen.gcdFree = s0 + CONFIG.gcd
  end

  out[#out+1] = { kind = "auto", t0 = autoStart, t1 = autoLand }
  gen.t = autoLand
end

-- Absorb a stall by moving the notes rather than by holding a growing
-- clock offset. Without this, every clip added to `hold` forever and the
-- timeline drifted further behind real time for the whole fight.
local function shiftPlan(d)
  if not d or d == 0 then return end
  for _, e in ipairs(state.plan) do
    e.t0 = e.t0 + d
    e.t1 = e.t1 + d
  end
  gen.t       = gen.t + d
  gen.gcdFree = gen.gcdFree + d
  state.gatePassed = state.gatePassed + d
  if state.gate then state.gate = state.gate + d end
end

-- Align the sequence to reality at the one moment it is unambiguous:
-- when you actually cast an instant. Multi is step 1, Arcane is step 3,
-- so casting one tells us exactly where in the rotation you are.
--
-- Notes starting within LOCK_AHEAD are untouched, so nothing near the
-- line can move. Only the far end is rebuilt, and only on your action --
-- at most once per instant cast. This is deliberately NOT run on a
-- timer; doing that is what made the bar thrash.
local LOCK_AHEAD = 0.7

-- Top up the queue to the horizon, then drop what has scrolled past.
local function advancePlan(now, horizon, tail)
  if not gen.seeded or ews() <= 0 then return end
  local guard = 0
  while gen.t < horizon and guard < 16 do
    generateCycle()
    guard = guard + 1
  end
  local keep = {}
  for _, e in ipairs(state.plan) do
    if e.t1 >= tail then keep[#keep+1] = e end
  end
  -- Backstop: no legitimate state needs hundreds of notes.
  while #keep > 200 do table.remove(keep, 1) end
  state.plan = keep
end

--------------------------------------------------------------------------
-- Frames
--------------------------------------------------------------------------

local function heightFor()
  if CONFIG.meleeLane then
    return CONFIG.laneH * 2 + CONFIG.laneGap + CONFIG.pad * 2
  end
  return CONFIG.laneH + CONFIG.pad * 2
end

local totalH = heightFor()

-- An unscaled holder owns the on-screen position; root sits inside it
-- and is the thing that gets scaled on impact. Scaling a frame that
-- carries its own SetPoint offsets would drag it across the screen,
-- because those offsets are read in the frame's own scale.
local holder = CreateFrame("Frame", "WeaveLineHolder", UIParent)
holder:SetSize(CONFIG.width, totalH)
holder:SetPoint("CENTER", UIParent, "CENTER", 0, -170)
holder:SetMovable(true); holder:EnableMouse(true)
holder:RegisterForDrag("LeftButton")
holder:SetScript("OnDragStart", function(self) if IsShiftKeyDown() then self:StartMoving() end end)
holder:SetScript("OnDragStop", function(self)
  self:StopMovingOrSizing()
  local p, _, rp, x, y = self:GetPoint()
  WeaveLineDB = WeaveLineDB or {}
  WeaveLineDB.pos = { p, rp, x, y }
end)

local root = CreateFrame("Frame", "WeaveLineRoot", holder)
root:SetSize(CONFIG.width, totalH)
root:SetPoint("CENTER", holder, "CENTER", 0, 0)

local panel = root:CreateTexture(nil, "BACKGROUND", nil, -2)
panel:SetAllPoints(root)
panel:SetColorTexture(unpack(C.panel))

local outline = {}
for i = 1, 4 do
  local t = root:CreateTexture(nil, "BACKGROUND", nil, -3)
  t:SetColorTexture(unpack(C.edge)); outline[i] = t
end
outline[1]:SetPoint("BOTTOM", root, "TOP", 0, 0)
outline[2]:SetPoint("TOP", root, "BOTTOM", 0, 0)
outline[3]:SetPoint("RIGHT", root, "LEFT", 0, 0)
outline[4]:SetPoint("LEFT", root, "RIGHT", 0, 0)

-- Inset grooves so empty bar still reads as a track.
local trackTop = root:CreateTexture(nil, "BACKGROUND", nil, -1)
trackTop:SetColorTexture(unpack(C.track))
trackTop:SetPoint("TOPLEFT", root, "TOPLEFT", CONFIG.pad, -CONFIG.pad)
trackTop:SetSize(CONFIG.width - CONFIG.pad*2, CONFIG.laneH)

local trackBot = root:CreateTexture(nil, "BACKGROUND", nil, -1)
trackBot:SetColorTexture(unpack(C.track))
trackBot:SetPoint("BOTTOMLEFT", root, "BOTTOMLEFT", CONFIG.pad, CONFIG.pad)
trackBot:SetSize(CONFIG.width - CONFIG.pad*2, CONFIG.laneH)

local hair = root:CreateTexture(nil, "BORDER")
hair:SetColorTexture(unpack(C.hairline))

-- Thin highlight along the top inside edge; reads as a lit surface
-- rather than a flat rectangle.
local sheen = root:CreateTexture(nil, "OVERLAY", nil, 5)
sheen:SetColorTexture(unpack(C.sheen))

local planSegs, actualSegs, tickTex = {}, {}, {}
for i = 1, 48 do
  local p = root:CreateTexture(nil, "ARTWORK"); p:Hide(); planSegs[i] = p
  local a = root:CreateTexture(nil, "ARTWORK"); a:Hide(); actualSegs[i] = a
end
for i = 1, 64 do
  local t = root:CreateTexture(nil, "OVERLAY", nil, 4)
  t:SetColorTexture(unpack(C.tick)); t:Hide(); tickTex[i] = t
end

-- Black separators sitting at the moment each ability should be pressed.
-- They double as the visual break between adjacent segments.
local sepTex = {}
for i = 1, 32 do
  local t = root:CreateTexture(nil, "OVERLAY", nil, 5)
  t:SetColorTexture(unpack(C.sep)); t:Hide(); sepTex[i] = t
end

-- One line per lane rather than a single bar through both. The break at
-- the divider keeps the two tracks reading as separate rows.
-- Impact flash. Above the segments, below the now-lines, and decays to
-- nothing so it can never be mistaken for a state on the bar itself.
local flash = root:CreateTexture(nil, "OVERLAY", nil, 6)
flash:SetColorTexture(1, 1, 1, 1)
flash:Hide()

-- Swing timer, hugging the bottom border.

-- Where the in-flight cast lands.
-- Ready-pips for the instants, sitting off the right end of the bar.
-- Each icon gets its OWN frame. Locked together in a row they still had
-- to share a spot; separately you can put Multi where your eye goes for
-- Multi and Arcane somewhere else entirely.
local PIPS = { "multi", "arcane", "kc" }
local pipHolder = {}
for i = 1, #PIPS do
  local h = CreateFrame("Frame", "WeaveLinePip" .. i, UIParent)
  h:SetSize(CONFIG.pipSize, CONFIG.pipSize)
  h:SetPoint("CENTER", UIParent, "CENTER", (i - 2) * 40, -120)
  h:SetMovable(true); h:EnableMouse(true)
  h:RegisterForDrag("LeftButton")
  h:SetScript("OnDragStart", function(self)
    if IsShiftKeyDown() then self:StartMoving() end
  end)
  h:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local p, _, rp, x, y = self:GetPoint()
    WeaveLineDB = WeaveLineDB or {}
    WeaveLineDB.pipPos = WeaveLineDB.pipPos or {}
    WeaveLineDB.pipPos[i] = { p, rp, x, y }
  end)
  pipHolder[i] = h
end

-- Holders for the readouts when free positioning is on. Same idea as the
-- icons: their own frame, shift-dragged, position saved separately.
local TEXTS = { "ews", "clip", "range" }
local textHolder = {}
for i = 1, #TEXTS do
  local h = CreateFrame("Frame", "WeaveLineText" .. i, UIParent)
  h:SetSize(90, 18)
  h:SetPoint("CENTER", UIParent, "CENTER", (i - 2) * 100, -150)
  h:SetMovable(true); h:EnableMouse(false)
  h:RegisterForDrag("LeftButton")
  h:SetScript("OnDragStart", function(self)
    if IsShiftKeyDown() then self:StartMoving() end
  end)
  h:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local p, _, rp, x, y = self:GetPoint()
    WeaveLineDB = WeaveLineDB or {}
    WeaveLineDB.textPos = WeaveLineDB.textPos or {}
    WeaveLineDB.textPos[i] = { p, rp, x, y }
  end)
  h:Hide()
  textHolder[i] = h
end

local pip = {}
for i = 1, #PIPS do
  local f = CreateFrame("Frame", nil, pipHolder[i])
  f:SetSize(CONFIG.pipSize, CONFIG.pipSize)
  f.glow = f:CreateTexture(nil, "BACKGROUND", nil, -1)
  f.glow:SetPoint("TOPLEFT", f, "TOPLEFT", -4, 4)
  f.glow:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 4, -4)
  f.glow:SetColorTexture(0, 0, 0, 0)

  -- Outline, drawn just outside the icon so it frames rather than crops.
  f.edge = f:CreateTexture(nil, "BORDER")
  f.edge:SetColorTexture(unpack(C.pipEdge))

  f.bg = f:CreateTexture(nil, "BACKGROUND")
  f.bg:SetAllPoints(f)
  f.bg:SetColorTexture(unpack(C.pipOff))
  f.icon = f:CreateTexture(nil, "ARTWORK")
  f.icon:SetAllPoints(f)
  f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  f.txt = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  f.txt:SetPoint("CENTER", f, "CENTER", 0, 0)
  f.txt:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")
  f.wasReady, f.popAt, f.castAt = false, 0, 0
  pip[i] = f
end

-- Soft edges. Sit above the segments, below the now-line, so anything
-- scrolling off dissolves instead of popping.
local fadeL = root:CreateTexture(nil, "OVERLAY", nil, 6)
local fadeR = root:CreateTexture(nil, "OVERLAY", nil, 6)

local function paintFades()
  local c = C.track
  for _, f in ipairs({ fadeL, fadeR }) do
    f:SetColorTexture(c[1], c[2], c[3], 1)
  end
  if CreateColor then
    pcall(function()
      fadeL:SetGradient("HORIZONTAL",
        CreateColor(c[1], c[2], c[3], 1), CreateColor(c[1], c[2], c[3], 0))
      fadeR:SetGradient("HORIZONTAL",
        CreateColor(c[1], c[2], c[3], 0), CreateColor(c[1], c[2], c[3], 1))
    end)
  end
end
paintFades()

-- The cast in flight, and the portion of it running past plan.
local castRun  = root:CreateTexture(nil, "OVERLAY", nil, 5)
castRun:SetColorTexture(unpack(C.castRun)); castRun:Hide()
local castOver = root:CreateTexture(nil, "OVERLAY", nil, 6)
castOver:SetColorTexture(unpack(C.castOver)); castOver:Hide()

-- Marks the end of the next auto: everything right of it is predicted.
local horizonTex = root:CreateTexture(nil, "OVERLAY", nil, 5)
horizonTex:SetColorTexture(unpack(C.horizon))
horizonTex:Hide()

-- Melee swing timer fill.
local meleeFill = root:CreateTexture(nil, "ARTWORK", nil, 2)
meleeFill:Hide()

-- Slack meter, its own strip under the addon.
-- Movement window fill for the top lane.
local moveFill = root:CreateTexture(nil, "ARTWORK", nil, 2)
moveFill:Hide()
local moveIcon = root:CreateTexture(nil, "OVERLAY", nil, 7)
moveIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
moveIcon:Hide()

local moveTxt = root:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
moveTxt:SetFont(STANDARD_TEXT_FONT, 15, "OUTLINE")

local slackBg = root:CreateTexture(nil, "ARTWORK", nil, 1)
slackBg:SetColorTexture(unpack(C.slkBack)); slackBg:Hide()
local slackFill = root:CreateTexture(nil, "ARTWORK", nil, 2)
slackFill:Hide()
local slackCast = root:CreateTexture(nil, "OVERLAY", nil, 3)
slackCast:SetColorTexture(1, 1, 1, 0.85); slackCast:Hide()
local slackTxt = root:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
slackTxt:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")

local castMark = root:CreateTexture(nil, "OVERLAY", nil, 7)
castMark:SetColorTexture(unpack(C.castEnd))
castMark:Hide()

local nowTop = root:CreateTexture(nil, "OVERLAY", nil, 7)
nowTop:SetColorTexture(1, 1, 1, 0.95)
nowTop:SetSize(CONFIG.lineWidth, CONFIG.laneH + 4)

local nowBot = root:CreateTexture(nil, "OVERLAY", nil, 7)
nowBot:SetColorTexture(1, 1, 1, 0.95)
nowBot:SetSize(CONFIG.lineWidth, CONFIG.laneH + 4)

local lblA = root:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
lblA:SetText("|cff6e7385YOU|r")

-- Stats spread across the width instead of crowded into one string.
local stat = {}
for i = 1, 4 do
  stat[i] = root:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
end


local rangeLabel = root:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")

local clipText = root:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
clipText:SetPoint("TOPRIGHT", root, "BOTTOMRIGHT", -2, -4)

--------------------------------------------------------------------------
-- Range
--
-- Classic has no exact distance API, so this is bracketed with the
-- probes that do exist: Raptor for melee, the duel interact check for
-- roughly ten yards, and Steady for shooting range.
--------------------------------------------------------------------------

local function setOutline(c)
  for i = 1, 4 do outline[i]:SetColorTexture(c[1], c[2], c[3], c[4] or 1) end
end

-- Range bands, using the probes from [HUNTER] Predictive Melee Weave.
-- Items have fixed ranges, which is the only reliable distance signal
-- Classic exposes. Melee is probed with Wing Clip rather than Raptor
-- Strike -- Raptor is a next-melee-attack ability and its range check
-- is not trustworthy, which is what made this read melee at distance.
local RANGE_ITEM = { sweet = 8149, close = 17626, shoot = 18904 }  -- 7 / 10 / 35 yd

-- Items with fixed ranges, nearest first. Same table the range-check
-- aura uses; it is the only fine-grained distance signal Classic has.
local RANGE_LADDER = {
  {  7, 8149  }, { 10, 17626 }, { 15, 33069 }, { 20, 10645 },
  { 25, 13289 }, { 30, 7734  }, { 35, 18904 },
}
local WING_CLIP  = 2974

local function wingClipInRange(u)
  if C_Spell and C_Spell.IsSpellInRange then
    local r = C_Spell.IsSpellInRange(WING_CLIP, u)
    if r ~= nil then return r == true or r == 1 end
  end
  if IsSpellInRange then
    local nm = spellInfo(WING_CLIP)
    if nm then return IsSpellInRange(nm, u) == 1 end
  end
  return nil
end

-- Second, independent melee probe. Auto Shot has a minimum range, so
-- being inside 10 yards while Auto Shot reports out-of-range means you
-- are inside that minimum -- which is melee. The range-check aura uses
-- exactly this. Two probes disagreeing is worth knowing about, so
-- /wl range prints both.
local function autoShotBlocked(u)
  if not (IsSpellInRange and SPELL.auto) then return nil end
  if not (IsItemInRange and IsItemInRange(17626, u)) then return false end
  return IsSpellInRange(SPELL.auto, u) ~= 1
end

local function inMelee(u)
  local wc = wingClipInRange(u)
  if wc then return true end
  if CONFIG.meleeUseAutoShot and autoShotBlocked(u) then return true end
  return false
end

local function itemInRange(id, u)
  return IsItemInRange and IsItemInRange(id, u) and true or false
end

local function rangeState()
  local u = "target"
  if not UnitExists(u) or not UnitCanAttack("player", u) or UnitIsDead(u) then
    return nil
  end
  if inMelee(u)                            then return "melee"  end
  if itemInRange(RANGE_ITEM.sweet, u)      then return "sweet"  end
  if itemInRange(RANGE_ITEM.shoot, u)      then return "ranged" end
  return "far"
end

local RANGE_COLOR = {
  melee  = "rngMelee",
  sweet  = "rngStep",
  ranged = "rngRanged",
  far    = "rngFar",
}

-- Bracket the target between two rungs of the ladder.
-- Hard bounds from every probe available. hi is the tightest rung that
-- reports true, lo the loosest that reports false.
local function probeBracket(u)
  local lo, hi = 0, 99
  if inMelee(u) then
    hi = math.min(hi, CONFIG.meleeRange)
  else
    lo = math.max(lo, CONFIG.meleeRange)
  end
  for _, r in ipairs(RANGE_LADDER) do
    if itemInRange(r[2], u) then
      if r[1] < hi then hi = r[1] end
    else
      if r[1] > lo then lo = r[1] end
    end
  end
  if lo > hi then lo = hi end
  return lo, hi
end

-- Dead reckoning between crossings, snapped exactly at each one.
local function updateDistance(now, dt)
  local u = "target"
  if not CONFIG.estimate or not UnitExists(u)
     or not UnitCanAttack("player", u) or UnitIsDead(u) then
    state.dist = nil
    return
  end

  -- Integrate first; speed is magnitude only, so direction comes from
  -- how the bracket has been moving.
  local sp = (GetUnitSpeed and GetUnitSpeed("player")) or 0
  if state.dist and sp > 0 and state.moveDir ~= 0 then
    state.dist = state.dist + state.moveDir * sp * dt
  end

  if (now - state.probeAt) < (1 / CONFIG.probeHz) then
    if state.dist then
      state.dist = math.min(state.probeHi, math.max(state.probeLo, state.dist))
    end
    return
  end
  state.probeAt = now

  local lo, hi = probeBracket(u)

  -- A crossing is an exact fix. Tightening means we closed through that
  -- rung; loosening means we opened through it.
  if hi < state.probeHi then
    state.dist, state.moveDir, state.fixAt = hi, -1, now
  elseif lo > state.probeLo then
    state.dist, state.moveDir, state.fixAt = lo, 1, now
  elseif hi > state.probeHi then
    state.moveDir = 1
  elseif lo < state.probeLo then
    state.moveDir = -1
  end

  state.probeLo, state.probeHi = lo, hi
  if not state.dist then
    state.dist, state.fixAt = (lo + hi) / 2, now
  end

  -- Confidence decay -- but ONLY while you are actually moving.
  --
  -- This exists because dead reckoning drifts toward a bracket edge with
  -- no crossing to correct it. Dead reckoning only drifts while it is
  -- INTEGRATING: standing still, GetUnitSpeed is 0, nothing accumulates,
  -- and the estimate is exactly as good as its last fix.
  --
  -- Decaying a stationary reading corrupted a number that was already
  -- correct: park at 5.1 in the 5-7 bracket and it eased to the 6.0
  -- midpoint while you had not moved at all.
  local age = now - state.fixAt
  if sp > 0.01 and age > CONFIG.fixTrust then
    local mid = (lo + hi) / 2
    local k = math.min(1, (age - CONFIG.fixTrust) / CONFIG.fixDecay)
    state.dist = state.dist + (mid - state.dist) * k * 0.25
  end

  state.dist = math.min(hi, math.max(lo, state.dist))
end

-- One-way travel to melee, from the tightest ladder rung that still
-- reports true. Nil when there is no target or it is out of range.
local function travelTime()
  local u = "target"
  if not UnitExists(u) or not UnitCanAttack("player", u) then return nil end
  if inMelee(u) then return 0 end

  local d
  if CONFIG.estimate and state.dist then
    d = state.dist - CONFIG.meleeRange
  else
    for _, r in ipairs(RANGE_LADDER) do
      if itemInRange(r[2], u) then d = r[1] - CONFIG.meleeRange break end
    end
  end
  if not d then return nil end
  if d < 0 then d = 0 end
  return d / CONFIG.runSpeed
end

-- Everything the meter needs, from facts only: your last real auto and
-- the live GCD. Returns state, the number that matters, and the bounds.
--
--   "open"   window is live; n = slack remaining before a Steady clips
--   "locked" GCD still down; n = time until the window opens
--   "none"   the window opens AFTER the deadline -- a clip is
--            unavoidable this cycle, which is what buys Multi/Arcane
--   "late"   deadline passed
local function slackState(real)
  if state.lastAuto == 0 then return nil end
  local rl, sc = reload(), steadyCast()
  if rl <= 0 or sc <= 0 then return nil end

  local deadline = state.lastAuto + rl - sc
  local cs, cd   = spellCD(SPELL.steady)
  local gcdFree  = (cs and cs > 0) and (cs + cd) or real
  local openAt   = math.max(state.lastAuto, gcdFree)

  -- Did the GCD start AFTER this auto landed? If so you already cast
  -- something this cycle and there is nothing left to decide. Without
  -- this the meter condemned you the instant you did the right thing:
  -- casting Steady locks the GCD for 1500ms, which is past the 652ms
  -- deadline, so it read as "no clean window" for the rest of the cycle.
  local gcdStart = gcdFree - CONFIG.gcd
  if gcdStart >= state.lastAuto - 0.05 then
    return "done", math.max(0, gcdFree - real), openAt, deadline
  end

  if openAt > deadline + 0.005 then
    return "none", openAt - deadline, openAt, deadline
  elseif real < openAt then
    return "locked", openAt - real, openAt, deadline
  elseif real <= deadline then
    return "open", deadline - real, openAt, deadline
  end
  return "late", real - deadline, openAt, deadline
end

local function rangeText()
  local u = "target"
  if not UnitExists(u) or not UnitCanAttack("player", u) or UnitIsDead(u) then
    return ""
  end
  if inMelee(u) then return "melee" end
  if CONFIG.estimate and state.dist then
    local stale = (GetTime() - state.fixAt) > CONFIG.fixTrust
    return string.format("%.1f yd%s", state.dist, stale and "~" or "")
  end
  local prev = 0
  for _, r in ipairs(RANGE_LADDER) do
    if itemInRange(r[2], u) then
      return string.format("%d-%d yd", prev, r[1])
    end
    prev = r[1]
  end
  return "35+ yd"
end

-- The border reports one of three things, chosen in the options:
--   "off"   plain edge; the range TEXT is unaffected
--   "range" the old distance colouring
--   "kc"    lights when Kill Command is castable
local function rangeColor()
  local mode = CONFIG.borderMode or "range"

  if mode == "kc" then
    if spellUsable(SPELLID.kc) and realCdLeft(SPELLID.kc) <= 0 then
      return C.kcEdge
    end
    return C.edge
  end

  if mode ~= "range" then return C.edge end
  local st = rangeState()
  if not st then return C.edge end
  return C[RANGE_COLOR[st]] or C.edge
end

--------------------------------------------------------------------------
-- Layout. Single place that knows how tall things are, so toggling the
-- YOU lane cannot leave anchors stale.
--------------------------------------------------------------------------

local innerW

local function layout()
  totalH = heightFor()
  innerW = CONFIG.width - CONFIG.pad * 2
  root:SetSize(CONFIG.width, totalH)

  local b = CONFIG.border
  outline[1]:SetSize(CONFIG.width + b * 2, b)
  outline[2]:SetSize(CONFIG.width + b * 2, b)
  outline[3]:SetSize(b, totalH + b * 2)
  outline[4]:SetSize(b, totalH + b * 2)

  -- Ranged lane always occupies the top.
  trackTop:ClearAllPoints()
  trackTop:SetPoint("TOPLEFT", root, "TOPLEFT", CONFIG.pad, -CONFIG.pad)
  trackTop:SetSize(innerW, CONFIG.laneH)
  trackTop:Show()

  nowTop:ClearAllPoints()
  nowTop:SetSize(CONFIG.lineWidth, CONFIG.laneH + 3)
  nowTop:SetPoint("TOP", root, "TOP", 0, -(CONFIG.pad - 1))
  if CONFIG.nowLine then nowTop:Show() else nowTop:Hide() end

  if CONFIG.meleeLane then
    trackBot:ClearAllPoints()
    trackBot:SetPoint("BOTTOMLEFT", root, "BOTTOMLEFT", CONFIG.pad, CONFIG.pad)
    trackBot:SetSize(innerW, CONFIG.laneH)
    trackBot:Show()

    hair:Show()
    hair:ClearAllPoints()
    hair:SetSize(innerW, 1)
    hair:SetPoint("CENTER", root, "CENTER", 0, 0)

    nowBot:ClearAllPoints()
    nowBot:SetSize(CONFIG.lineWidth, CONFIG.laneH + 3)
    nowBot:SetPoint("BOTTOM", root, "BOTTOM", 0, CONFIG.pad - 1)
    if CONFIG.nowLine then nowBot:Show() else nowBot:Hide() end
  else
    trackBot:Hide(); hair:Hide(); nowBot:Hide()
  end

  lblA:Hide()

  for i = 1, #PIPS do
    pip[i]:ClearAllPoints()
    pip[i]:SetSize(CONFIG.pipSize, CONFIG.pipSize)
    -- Laid out inside their own frame now, so the bar's anchors and
    -- border no longer come into it.
    pip[i]:SetPoint("CENTER", pipHolder[i], "CENTER", 0, 0)
    local e = CONFIG.pipBorder and (CONFIG.pipBorderSz or 2) or 0
    pip[i].edge:ClearAllPoints()
    pip[i].edge:SetPoint("TOPLEFT", pip[i], "TOPLEFT", -e, e)
    pip[i].edge:SetPoint("BOTTOMRIGHT", pip[i], "BOTTOMRIGHT", e, -e)
    pip[i].edge:SetColorTexture(unpack(C.pipEdge))
    if e > 0 then pip[i].edge:Show() else pip[i].edge:Hide() end
    if CONFIG.pips then pip[i]:Show() else pip[i]:Hide() end
  end
  for i = 1, #PIPS do
    pipHolder[i]:SetSize(CONFIG.pipSize, CONFIG.pipSize)
    pcall(function() pipHolder[i]:SetScale(CONFIG.pipScale or 1) end)
    local on = CONFIG.pips and
      ((i == 1 and CONFIG.showMulti) or (i == 2 and CONFIG.showArcane)
        or (i == 3 and CONFIG.showKC))
    if on then pipHolder[i]:Show() else pipHolder[i]:Hide() end
  end

  flash:ClearAllPoints(); flash:SetAllPoints(root)

  local tg = CONFIG.border + CONFIG.textGap

  -- Either anchored to the bar, or floating on their own frame. Same
  -- fontstring either way; only its parent and point change.
  local function place(fs, key, idx)
    fs:ClearAllPoints()
    if CONFIG.freeText then
      local h = textHolder[idx]
      fs:SetParent(h)
      fs:SetPoint("CENTER", h, "CENTER", 0, 0)
      h:EnableMouse(true)
      h:Show()
    else
      local a = ANCHORS[CONFIG[key]] or ANCHORS.TOPLEFT
      fs:SetParent(root)
      fs:SetPoint(a[1], root, a[2], a[3], tg * a[4])
      textHolder[idx]:EnableMouse(false)
      textHolder[idx]:Hide()
    end
  end

  place(stat[1],    "posEws",   1)
  place(clipText,   "posClip",  2)
  place(rangeLabel, "posRange", 3)

  -- 2..4 are unused; park them out of the way.
  for i = 2, 4 do
    stat[i]:ClearAllPoints()
    stat[i]:SetPoint("TOP", root, "BOTTOM", 0, -tg)
  end

  local fw = math.max(0, CONFIG.edgeFade)
  fadeL:ClearAllPoints()
  fadeL:SetPoint("TOPLEFT", root, "TOPLEFT", CONFIG.pad, -CONFIG.pad)
  fadeL:SetPoint("BOTTOMLEFT", root, "BOTTOMLEFT", CONFIG.pad, CONFIG.pad)
  fadeL:SetWidth(fw)
  fadeR:ClearAllPoints()
  fadeR:SetPoint("TOPRIGHT", root, "TOPRIGHT", -CONFIG.pad, -CONFIG.pad)
  fadeR:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", -CONFIG.pad, CONFIG.pad)
  fadeR:SetWidth(fw)
  if fw > 0 then fadeL:Show(); fadeR:Show() else fadeL:Hide(); fadeR:Hide() end

  local sy = -(CONFIG.border + CONFIG.textGap + 14 + CONFIG.slackGap)
  moveFill:ClearAllPoints()
  moveFill:SetPoint("TOPLEFT", root, "TOPLEFT", CONFIG.pad, -CONFIG.pad)
  moveFill:SetHeight(CONFIG.laneH)
  local ih = CONFIG.laneH - 4
  moveIcon:ClearAllPoints()
  moveIcon:SetSize(ih, ih)
  moveIcon:SetPoint("LEFT", root, "TOPLEFT", CONFIG.pad + 2,
                    -(CONFIG.pad + CONFIG.laneH * 0.5))
  moveTxt:ClearAllPoints()
  moveTxt:SetPoint("LEFT", moveIcon, "RIGHT", 6, 0)

  slackBg:ClearAllPoints()
  slackBg:SetPoint("TOPLEFT", root, "BOTTOMLEFT", 0, sy)
  slackBg:SetSize(CONFIG.width, CONFIG.slackH)
  slackFill:ClearAllPoints()
  slackFill:SetPoint("TOPLEFT", root, "BOTTOMLEFT", 0, sy)
  slackFill:SetHeight(CONFIG.slackH)
  slackTxt:ClearAllPoints()
  slackTxt:SetPoint("LEFT", slackBg, "RIGHT", 6, 0)

  sheen:ClearAllPoints()
  sheen:SetPoint("TOPLEFT", root, "TOPLEFT", 1, -1)
  sheen:SetPoint("TOPRIGHT", root, "TOPRIGHT", -1, -1)
  sheen:SetHeight(1)
end

--------------------------------------------------------------------------
-- Geometry
--------------------------------------------------------------------------

local pps, lineX, lookahead, lookbehind

local function recomputeGeometry()
  -- Scale off the SAME interval the notes are spaced by. Using eWS here
  -- while the grid ran at the measured rhythm meant a "cycle" of
  -- lookahead did not match an actual cycle on the bar.
  local speed = cycleLength(); if speed <= 0 then speed = 2.0 end
  lookahead = CONFIG.cycles * speed
  local p = math.min(0.9, math.max(0.05, CONFIG.linePos))
  lookbehind = lookahead * p / (1 - p)
  pps   = innerW / (lookahead + lookbehind)
  lineX = -(innerW / 2) + innerW * p
  nowTop:ClearAllPoints()
  nowTop:SetPoint("TOP", root, "TOP", lineX, -(CONFIG.pad - 1))
  nowBot:ClearAllPoints()
  nowBot:SetPoint("BOTTOM", root, "BOTTOM", lineX, CONFIG.pad - 1)
end

local function applyFont()
  -- SetFont returns false when the file is missing, and a failed call can
  -- leave a label with no font at all -- i.e. invisible. Try each
  -- candidate, verify it took, and fall back to the stock font.
  -- Verify by reading the font BACK. A failed SetFont leaves the old
  -- font in place, so GetFont() still returns something valid -- checking
  -- it is non-nil passes even when the file was never found. Comparing
  -- it to the path we asked for is the only real test.
  local chosen
  local probe = rangeLabel
  for _, cand in ipairs(fontPaths(CONFIG.fontFace) or {}) do
    local ok = pcall(function() probe:SetFont(cand, 12, "OUTLINE") end)
    if ok then
      local cur = probe:GetFont()
      if cur and cur:lower() == cand:lower() then chosen = cand break end
    end
  end
  local path = chosen or STANDARD_TEXT_FONT

  local function set(fs, size)
    if fs then
      local ok, res = pcall(function()
        return fs:SetFont(path, size or 12, "OUTLINE")
      end)
      if not ok or res == false then
        pcall(function() fs:SetFont(STANDARD_TEXT_FONT, size or 12, "OUTLINE") end)
      end
    end
  end

  -- The three readouts size independently: they carry different kinds of
  -- information and you may want the one you glance at biggest.
  set(rangeLabel, CONFIG.rangeSize)
  set(clipText,   CONFIG.clipSize)
  for i = 1, 4 do set(stat[i], CONFIG.ewsSize) end

  -- The state label leads, so it stays a few points above the rest.
  set(moveTxt, (CONFIG.fontSize or 12) + 3)
  set(slackTxt, CONFIG.fontSize)
  for i = 1, #PIPS do
    if pip[i] and pip[i].txt then set(pip[i].txt, CONFIG.fontSize) end
  end
end

local function applySkin()
  local skin
  for _, sk in ipairs(SKINS) do
    if sk.name == CONFIG.skin then skin = sk break end
  end
  -- Reset to the captured baseline first, so switching skins is not
  -- cumulative and "Default" genuinely restores.
  for k, v in pairs(BASE_CFG) do CONFIG[k] = v end
  for k, v in pairs(BASE_COL) do
    if C[k] then C[k][1], C[k][2], C[k][3] = v[1], v[2], v[3] end
  end
  if skin then
    for k, v in pairs(skin.cfg) do CONFIG[k] = v end
    for k, v in pairs(skin.col) do
      if C[k] then C[k][1], C[k][2], C[k][3] = v[1], v[2], v[3] end
    end
  end
  layout(); recomputeGeometry(); applyFont()
end

layout()
recomputeGeometry()

local function xFor(t, now) return lineX + (t - now) * pps end

--------------------------------------------------------------------------
-- Render
--------------------------------------------------------------------------

local function ms(v)
  if type(v) ~= "number" or v ~= v then return "0" end
  v = v * 1000
  if v < -9999 then v = -9999 elseif v > 9999 then v = 9999 end
  return string.format("%.0f", v)
end

local function render()
  local real  = GetTime()
  -- Timeline clock. Stops advancing while gated, so the track holds at
  -- the auto shot instead of running ahead of you.
  local now   = real - state.hold
  local halfW = innerW / 2
  recomputeGeometry()

  local nP, nA, nT, nS = 0, 0, 0, 0

  -- Set below, once the queue is up to date.
  local certainUntil = now

  local function seg(pool, count, e, lane)
    if count >= #pool then return count end

    local col = C[e.kind]
    local idle = (e.kind == "down")
    if idle then
      if CONFIG.idleStyle == "hidden" then return count end
      if (e.t1 - e.t0) < CONFIG.idleMin then return count end
      if CONFIG.idleStyle == "tail" then
        -- Borrow the colour of whatever is still holding you.
        col = C[e.after or "steady"] or C.down
      end
    end
    if not col then return count end
    local x0 = math.max(xFor(e.t0, now), -halfW)
    local x1 = math.min(xFor(e.t1, now),  halfW)
    if x1 - x0 <= 0.5 then return count end
    count = count + 1
    local z = pool[count]
    local past = (e.t1 < now)
    local a
    if idle then
      a = (CONFIG.idleStyle == "tail") and CONFIG.idleTailAlpha or 0.75
    else
      a = 0.98
    end
    if past then a = a * 0.32 end
    -- Smooth confidence ramp: full at the line, ghostAlpha at the far
    -- edge. Continuous in time, so nothing steps when a shot lands.
    if e.t0 > now then
      local k = (e.t0 - now) / lookahead
      if k > 1 then k = 1 end
      a = a * (1 - (1 - CONFIG.ghostAlpha) * k)
    end
    paint(z, col, a)
    z:ClearAllPoints()
    local h = idle and math.max(2, CONFIG.laneH * CONFIG.idleHeight) or CONFIG.laneH
    z:SetSize(x1 - x0, h)
    local cx = x0 + (x1 - x0) / 2
    if lane == "TOP" then
      z:SetPoint("CENTER", root, "TOP", cx, -(CONFIG.pad + CONFIG.laneH * 0.5))
    else
      z:SetPoint("CENTER", root, "BOTTOM", cx, CONFIG.pad + CONFIG.laneH * 0.5)
    end
    z:Show()
    return count
  end

  -- Split per lane, and coloured to match the input it introduces, so a
  -- glance at the line tells you which button is coming.
  local function tick(t, kind)
    if not CONFIG.ticks or nT + 1 >= #tickTex then return end
    local x = xFor(t, now)
    if x < -halfW or x > halfW then return end
    local c = C[kind] or C.tick
    local lanes = { "TOP" }
    for _, lane in ipairs(lanes) do
      nT = nT + 1
      local z = tickTex[nT]
      local ka = 0.95
      if t > now then
        local k = (t - now) / lookahead
        if k > 1 then k = 1 end
        ka = 0.95 * (1 - (1 - CONFIG.ghostAlpha) * k)
      end
      z:SetColorTexture(c[1], c[2], c[3], ka)
      z:ClearAllPoints(); z:SetSize(2, CONFIG.laneH)
      if lane == "TOP" then z:SetPoint("TOP", root, "TOP", x, -CONFIG.pad)
      else                  z:SetPoint("BOTTOM", root, "BOTTOM", x, CONFIG.pad) end
      z:Show()
    end
  end

  -- Notes are drawn at (t + slew), so the window in NOTE time is
  -- shifted by -slew. Generating against the unshifted window leaves the
  -- track short at one edge whenever the correction is large.
  advancePlan(now, now + lookahead + 1, now - lookbehind - 1)

  -- The horizon of certainty: the end of the next auto shot. That one is
  -- arithmetic on your last real shot. Everything after it is a guess.
  certainUntil = now + lookahead + 1
  for _, e in ipairs(state.plan) do
    if e.kind == "auto" and e.t1 >= now and e.t1 < certainUntil then
      certainUntil = e.t1
    end
  end

  if CONFIG.horizonMark then
    local hx = xFor(certainUntil, now)
    if hx >= -halfW and hx <= halfW then
      horizonTex:ClearAllPoints()
      horizonTex:SetSize(1, CONFIG.laneH)
      horizonTex:SetPoint("CENTER", root, "TOP", hx,
                          -(CONFIG.pad + CONFIG.laneH * 0.5))
      horizonTex:Show()
    else
      horizonTex:Hide()
    end
  else
    horizonTex:Hide()
  end

  -- Gating only makes sense while shots are actually landing. Idle, the
  -- timeline would reach a gate, stall for the full cap, time out and
  -- repeat -- a stutter every gateMax seconds. Three cycles of slack so
  -- the weave macro toggling attack off does not trip it.
  local shooting = state.lastAuto > 0
                   and (real - state.lastAuto) < (ews() * 3)

  -- The bar cannot flow past an auto shot. Either it is running at full
  -- speed or it is stopped at the line waiting for your real shot.
  state.holding = false

  if CONFIG.gateOnAuto and shooting then
    local g
    for _, e in ipairs(state.plan) do
      if e.kind == "auto" and e.t1 > state.gatePassed + 0.01 then
        if not g or e.t1 < g then g = e.t1 end
      end
    end
    state.gate = g

    if g and g <= now then
      if state.hold < CONFIG.gateMax then
        state.holding = true
      else
        -- Bounded: a dead target or walking out of range must not
        -- freeze the bar indefinitely.
        shiftPlan(state.hold)
        state.hold = 0
        state.gatePassed = g
      end
    end
  end
  -- A separator marks the instant the NEXT ability wants pressing, so
  -- it lands on the leading edge of every actionable segment.
  -- Coloured to match the input it introduces, lightened so it still
  -- reads as an edge against that input rather than merging into it.
  local function sep(t, kind)
    if not CONFIG.separators or nS >= #sepTex then return end
    local x = xFor(t, now)
    if x < -halfW or x > halfW then return end
    nS = nS + 1
    local z = sepTex[nS]
    local c = C[kind] or C.sep
    local k = CONFIG.sepBright
    local a = 1
    if t > now then
      local k = (t - now) / lookahead
      if k > 1 then k = 1 end
      a = 1 - (1 - CONFIG.ghostAlpha) * k
    end
    z:SetColorTexture(c[1] + (1 - c[1]) * k,
                      c[2] + (1 - c[2]) * k,
                      c[3] + (1 - c[3]) * k, a)
    z:ClearAllPoints()
    z:SetSize(CONFIG.sepWidth, CONFIG.laneH + CONFIG.sepOverhang * 2)
    z:SetPoint("CENTER", root, "TOP", x, -(CONFIG.pad + CONFIG.laneH * 0.5))
    z:Show()
  end

  for _, e in ipairs(state.plan) do
    if e.t1 > now - lookbehind and e.t0 < now + lookahead then
      if not CONFIG.weaveBar and (e.kind ~= "down" or CONFIG.showIdle) then
        nP = seg(planSegs, nP, e, "TOP")
      end
      if not CONFIG.weaveBar and (e.kind == "steady" or e.kind == "multi"
         or e.kind == "arcane" or e.kind == "weave") then
        sep(e.t0, e.kind)
      end
      if not CONFIG.weaveBar and e.kind ~= "down" and e.t0 >= now then
        tick(e.t0, e.kind)
      end
    end
  end


  for i = nP + 1, #planSegs   do planSegs[i]:Hide()   end
  for i = nA + 1, #actualSegs do actualSegs[i]:Hide() end
  for i = nT + 1, #tickTex    do tickTex[i]:Hide()    end
  for i = nS + 1, #sepTex     do sepTex[i]:Hide()     end

  -- Impact flash decays over its window; the outline rides along with it
  -- and drops straight back to the range colour once it is done.
  -- Impact. Full brightness on the first frame then a hard cubic decay,
  -- so it lands as a hit rather than a fade. The border thickens and the
  -- now-line swells at the same time; three things moving together is
  -- what makes it feel like contact instead of a colour change.
  local rc = rangeColor()
  local popped = false
  if state.impactAt > 0 then
    local left = 1 - ((real - state.impactAt) / state.impactDur)
    if left > 0 then
      local strong = state.impactStrong
      local e2 = left * left

      -- The scale pop is the primary cue. Full size on the first frame,
      -- then settling back -- a swell you feel rather than a flicker you
      -- have to catch. Everything else rides along with it.
      local amt = CONFIG.impactScale * (strong and 1.0 or 0.6) * e2
      root:SetScale(1 + amt)

      local blink = 0.5 + 0.5 * math.cos((1 - left) * math.pi * 2 * CONFIG.impactBlinks)
      local a = math.min(1, CONFIG.impactPeak * (strong and 1.0 or 0.6)
                            * e2 * (0.5 + 0.5 * blink))
      local g = 0.75 + 0.25 * blink
      flash:SetColorTexture(g, g, g, a)
      flash:Show()

      local m = e2 * (strong and 0.9 or 0.6)
      rc = { rc[1] + (1 - rc[1]) * m, rc[2] + (1 - rc[2]) * m, rc[3] + (1 - rc[3]) * m, 1 }

      local pop = math.floor(CONFIG.impactPop * e2 * (strong and 1.0 or 0.6) + 0.5)
      if pop > 0 then
        local b = CONFIG.border + pop
        outline[1]:SetSize(CONFIG.width + b*2, b)
        outline[2]:SetSize(CONFIG.width + b*2, b)
        outline[3]:SetSize(b, totalH + b*2)
        outline[4]:SetSize(b, totalH + b*2)
        popped = true
      end
    else
      state.impactAt = 0
      flash:Hide()
      root:SetScale(1)
    end
  elseif root:GetScale() ~= 1 then
    root:SetScale(1)
  end

  if not popped and state.impactAt == 0 then
    local b = CONFIG.border
    outline[1]:SetSize(CONFIG.width + b*2, b)
    outline[2]:SetSize(CONFIG.width + b*2, b)
    outline[3]:SetSize(b, totalH + b*2)
    outline[4]:SetSize(b, totalH + b*2)
    nowBot:SetWidth(CONFIG.lineWidth)
  end
  setOutline(rc)

  -- Instant cooldowns as pips: lit and empty when ready, dark with
  -- seconds when not. Continuous state, so it does not belong on a
  -- scrolling timeline.
  if CONFIG.pips then
    local defs = {
      { ICON.multi,  SPELLID.multi,  false },
      { ICON.arcane, SPELLID.arcane, false },
      { ICON.kc,     SPELLID.kc,     true  },   -- proc-gated
    }
    local shown = {
      CONFIG.showMulti, CONFIG.showArcane, CONFIG.showKC,
    }
    for i = 1, #PIPS do
      local f  = pip[i]
      if not shown[i] then
        pipHolder[i]:Hide()
      else
        pipHolder[i]:Show()
      end
      local cd = realCdLeft(defs[i][2])

      -- The NUMBER is the spell's own cooldown and nothing else, so it
      -- only ever counts down. Folding the GCD into it made the figure
      -- jump back to ~1.5s on every input, which is unreadable.
      -- Castability is carried by brightness instead.
      local cs, gd = spellCD(SPELL.steady)
      local gcdLeft = (cs and cs > 0) and math.max(0, (cs + gd) - real) or 0
      -- Kill Command is off the GCD and gated by a pet-crit proc, so
      -- neither the GCD nor a cooldown read tells you whether it is
      -- castable. Ask the game directly.
      local ready
      if defs[i][3] then
        ready = spellUsable(defs[i][2]) and cd <= 0
      else
        ready = (cd <= 0) and (gcdLeft <= 0)
      end
      f.icon:SetTexture(defs[i][1])

      -- Pop on the transition to ready: the moment it becomes actionable
      -- is the only moment worth drawing the eye.
      if ready and not f.wasReady then f.popAt = real end
      f.wasReady = ready

      if ready then
        f.icon:SetAlpha(1.0); f.txt:SetText("")
        if CONFIG.pipGlow then
          if defs[i][3] then
            -- Kill Command pulses rather than sitting lit. A steady glow
            -- disappears into a busy raid frame; movement does not.
            local pulse = 0.55 + 0.45 * math.abs(math.sin(real * 4))
            local g = C.kcLit
            f.glow:SetColorTexture(g[1], g[2], g[3],
                                   pulse * (CONFIG.kcGlow or 1))
          else
            f.glow:SetColorTexture(unpack(C.pipLit))
          end
        else
          f.glow:SetColorTexture(0, 0, 0, 0)
        end
      else
        -- Off cooldown but GCD-locked reads as bright-but-not-lit, with
        -- no number: there is nothing left to wait for except the GCD,
        -- which the bar below is already showing.
        f.icon:SetAlpha(cd > 0 and 0.25 or 0.75)
        if cd <= 0 then
          f.txt:SetText("")
        elseif cd >= 1 then
          f.txt:SetText(string.format("%.0f", cd + 0.5))
        else
          f.txt:SetText(string.format("%.0f", cd * 1000))
        end
        f.glow:SetColorTexture(0, 0, 0, 0)
      end

      local sc = 1

      -- Coming off cooldown is a small swell.
      if f.popAt > 0 then
        local left = 1 - ((real - f.popAt) / CONFIG.pipPop)
        if left > 0 then sc = 1 + 0.30 * left * left else f.popAt = 0 end
      end

      -- Actually firing it is the loud one: a big swell plus a white
      -- flare, so a cast going out is unmistakable.
      if f.castAt > 0 then
        local left = 1 - ((real - f.castAt) / CONFIG.pipCastPop)
        if left > 0 then
          local e2 = left * left
          sc = math.max(sc, 1 + CONFIG.pipCastGrow * e2)
          f.glow:SetColorTexture(1, 1, 1, 0.35 + 0.65 * e2)
        else
          f.castAt = 0
        end
      end
      f:SetSize(CONFIG.pipSize * sc, CONFIG.pipSize * sc)
      f:Show()
    end
  else
    pip[1]:Hide(); pip[2]:Hide()
  end

  -- Your actual cast, laid over the plan. The red overhang is the part
  -- running later than the plan's Steady -- the clip, shown while it is
  -- happening rather than tidied away by the correction afterwards.
  if CONFIG.castBar and not CONFIG.weaveBar then
    local cs, ce = castWindow()
    if cs and ce and ce > cs then
      -- Where the plan wanted this Steady to finish.
      -- Closest planned Steady by start time. Taking the first that
      -- merely overlapped could latch onto a neighbouring cycle and
      -- report a wildly wrong overhang, or none at all.
      local planEnd, bestD
      for _, e in ipairs(state.plan) do
        if e.kind == "steady" then
          local d = math.abs(e.t0 - cs)
          if d < 1.0 and (not bestD or d < bestD) then
            bestD, planEnd = d, e.t1
          end
        end
      end

      local function strip(tex, t0, t1)
        local x0 = math.max(xFor(t0, now), -halfW)
        local x1 = math.min(xFor(t1, now),  halfW)
        if x1 - x0 <= 0.5 then tex:Hide() return end
        tex:ClearAllPoints()
        tex:SetSize(x1 - x0, math.max(3, CONFIG.laneH * 0.30))
        tex:SetPoint("CENTER", root, "TOP",
                     x0 + (x1 - x0) / 2, -(CONFIG.pad + CONFIG.laneH * 0.5))
        tex:Show()
      end

      local onPlan = planEnd and math.min(ce, planEnd) or ce
      strip(castRun, cs, onPlan)
      if planEnd and ce > planEnd + 0.01 then
        strip(castOver, planEnd, ce)
      else
        castOver:Hide()
      end
    else
      castRun:Hide(); castOver:Hide()
    end
  else
    castRun:Hide(); castOver:Hide()
  end

  -- Cast completion. A tick where the in-flight cast lands, so the
  -- question that actually matters -- will this finish before the auto --
  -- is answered by looking at one bar instead of two.
  if CONFIG.castTick and not CONFIG.weaveBar then
    local ce = castEndsAt()
    if ce then
      local x = xFor(ce, now)
      if x >= -halfW and x <= halfW then
        castMark:ClearAllPoints()
        castMark:SetSize(CONFIG.castTickW, CONFIG.laneH + 6)
        castMark:SetPoint("CENTER", root, "TOP", x,
                          -(CONFIG.pad + CONFIG.laneH * 0.5))
        castMark:Show()
      else
        castMark:Hide()
      end
    else
      castMark:Hide()
    end
  else
    castMark:Hide()
  end

  -- Swing timer. Fills across as the swing recharges, empties the moment
  -- it lands. Real time, not the timeline clock: swings do not pause
  -- when the gate holds.
  -- Melee lane: a plain swing timer, Fluffy-style. Fills right to left
  -- as the swing recharges and empties when it lands. Colour is what is
  -- available, so one glance answers both "how long" and "worth it".
  if CONFIG.meleeLane then
    local sp   = meleeSpeed()
    local live = state.lastSwing > 0 and (real - state.lastSwing) < sp * CONFIG.swingStale
    local rdy  = realCdLeft(SPELL.raptor) <= 0
    local tint = rdy and C.swingUp or C.swingCd

    -- Recessed groove behind it so the lane reads as a track when empty.
    trackBot:SetColorTexture(tint[1] * 0.16, tint[2] * 0.16, tint[3] * 0.16, 0.95)

    if live then
      local pct = (real - state.lastSwing) / sp
      if pct > 1 then pct = 1 end
      local w = innerW * pct
      if w < 1 then w = 1 end
      meleeFill:SetColorTexture(tint[1], tint[2], tint[3], 0.95)
      meleeFill:ClearAllPoints()
      meleeFill:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", -CONFIG.pad, CONFIG.pad)
      meleeFill:SetSize(w, CONFIG.laneH)
      meleeFill:Show()
    else
      meleeFill:Hide()
    end
  else
    meleeFill:Hide()
  end

  -- Top lane: the movement window. Rooted while a cast is running, free
  -- once it ends, hold still while the auto animates. Every boundary is
  -- derived from your last real auto, so there is nothing to drift.
  if CONFIG.weaveBar then
    trackTop:SetColorTexture(unpack(C.mvBack))
    local la = state.lastAuto
    local cs, castTo, castName, castIcon, chan = castWindow()

    -- A cast is worth drawing whether or not you have ever fired a shot.
    -- All of this used to live inside "if la > 0", so out of combat the
    -- lane sat blank no matter what you were casting.
    local casting = (castTo and castTo > real) or
                    (state.castEndAt > 0
                     and (real - state.castEndAt) < CONFIG.castHold
                     and (real - state.castEndAt) >= 0)

    if la > 0 or casting then
      -- With no auto to reference, park these far enough ahead that the
      -- auto branches cannot fire; the cast branches run instead.
      local aStart = (la > 0) and (la + reload())      or (real + 3600)
      local aLand  = (la > 0) and (la + cycleLength()) or (real + 3600)

      -- kind drives the scale and the text format. Matching on the
      -- label broke once labels started carrying spell names.
      -- Remember the cast in flight so it can be held on screen for a
      -- moment after it finishes.
      if castTo and castName then
        state.castEndAt   = castTo
        state.castEndName = castName
        state.castEndIcon = castIcon
      end

      local col, left, label, icon, kind
      if castTo and castTo > real then
        -- Name whatever it is rather than saying "CAST", so Aimed,
        -- Volley and Multi are all readable on the same bar.
        local short = castName or "CAST"
        if #short > 14 then short = short:sub(1, 13) .. "." end
        local over = castTo - aStart
        if over > 0.005 and not chan then
          -- Channels are a deliberate stop, so a clip warning on one is
          -- noise: you already know you are not auto shooting.
          col, label, kind = C.mvOver, short .. " CLIP +" .. ms(over), "clip"
        else
          col, label, kind = (chan and C.mvChan or C.mvCast), short, "cast"
        end
        left = castTo - real
        icon = castIcon or ICON.steady
      elseif state.castEndAt > 0
         and (real - state.castEndAt) < CONFIG.castHold
         and (real - state.castEndAt) >= 0 then
        -- Just finished. Held briefly so a 362ms Multi is something you
        -- can actually see land.
        local short = state.castEndName or "CAST"
        if #short > 14 then short = short:sub(1, 13) .. "." end
        col, kind = C.mvDone, "done"
        left  = CONFIG.castHold - (real - state.castEndAt)
        label = short
        icon  = state.castEndIcon or ICON.steady

      elseif real < aStart then
        -- No instant cues on this lane at all. Multi has a real cast
        -- time so it appears in the CAST state on its own, and Arcane
        -- lives on the pip above the bar. This lane is only ever about
        -- what the AUTO is doing and whether the trip is worth taking.
        --
        -- Only call it MOVE if a swing would actually land while you are
        -- there. Travelling in for nothing costs position and returns no
        -- damage.
        -- Bound the period. If meleeSpeed() ever returns 0 this loop
        -- never advances and locks the client up.
        local sp = meleeSpeed()
        local nextSwing
        if sp and sp > 0.05 and state.lastSwing > 0 then
          nextSwing = state.lastSwing + sp
          local guard = 0
          while nextSwing < real and guard < 500 do
            nextSwing = nextSwing + sp
            guard = guard + 1
          end
        end

        if nextSwing and nextSwing <= aStart then
          col, left, label, icon, kind =
            C.mvFree, aStart - real, "MOVE", ICON.raptor, "move"
        else
          -- Free, but nothing to collect by going in. Report how much
          -- downtime is left before you need to be still.
          col, left, label, kind = C.mvWait, aStart - real, "DOWNTIME", "down"
          icon = ICON.raptor
        end

      else
        local late = real - aLand
        if late <= 0 then
          col, left, label, kind = C.mvHold, -late, "AUTO SHOT", "auto"
          icon = ICON.auto
        else
          -- Past due. While you are in melee Auto Shot is off, so the
          -- shot just waits -- and lastAuto goes stale, which is why
          -- this used to draw an empty bar with nothing to count. The
          -- delay you are accruing is the number that decides when to
          -- step back out, so show that instead.
          col, left, kind = C.mvLate, late, "late"
          icon = ICON.auto
          -- One label either way. Splitting it by melee range said
          -- nothing the number did not: the shot is late, and by how
          -- much is the only part that matters.
          if late >= CONFIG.lateCap then
            label = "AUTO LATE +" .. ms(CONFIG.lateCap) .. "ms+"
          else
            label = "AUTO LATE +" .. ms(late) .. "ms"
          end
        end
      end

      -- Full bar per state, or one shared scale if you prefer widths to
      -- mean duration.
      local span
      if CONFIG.fullBar then
        if kind == "cast" or kind == "clip" then
          -- Scale to the real length of whatever is being cast, so a 3s
          -- Aimed and a 0.5s Multi both fill the bar honestly.
          span = (cs and castTo > cs) and (castTo - cs) or steadyCast()
        elseif kind == "done" then
          span = CONFIG.castHold
        elseif kind == "move" or kind == "down" then
          span = reload() - steadyCast()
        elseif kind == "late" then
          -- Fills over a whole cycle, so the bar grows the longer you
          -- stay in.
          span = cycleLength()
        else
          span = autoCast()
        end
      else
        span = cycleLength()
      end
      if span <= 0 then span = 0.001 end
      local w = (math.min(left, span) / span) * innerW
      if w < 1 then w = 1 end
      moveFill:SetColorTexture(col[1], col[2], col[3], 0.95)
      moveFill:SetWidth(w)
      moveFill:Show()
      moveIcon:SetTexture(icon)
      moveIcon:SetAlpha(kind == "down" and 0.35 or 1.0)
      moveIcon:Show()
      moveTxt:SetTextColor(C.txtState[1], C.txtState[2], C.txtState[3])
      if kind == "clip" or kind == "late" then
        moveTxt:SetText(label)
      else
        moveTxt:SetText(label .. "  " .. ms(left))
      end
    else
      moveFill:Hide(); moveIcon:Hide(); moveTxt:SetText("")
    end
  else
    moveFill:Hide(); moveIcon:Hide(); moveTxt:SetText("")
  end

  -- Slack meter.
  if CONFIG.slackMeter then
    local st, n, openAt, deadline = slackState(real)
    if st then
      slackBg:Show()
      local span = deadline - state.lastAuto
      if span <= 0 then span = 0.001 end

      if st == "open" then
        -- Drains left to right as your slack runs out.
        local w = (n / span) * CONFIG.width
        if w < 1 then w = 1 end
        slackFill:SetColorTexture(unpack(C.slkOpen))
        slackFill:SetWidth(w); slackFill:Show()
        slackTxt:SetTextColor(0.35, 1, 0.4)
        slackTxt:SetText(ms(n) .. "ms")

      elseif st == "locked" then
        local w = (1 - math.min(1, n / span)) * CONFIG.width
        if w < 1 then w = 1 end
        slackFill:SetColorTexture(unpack(C.slkLock))
        slackFill:SetWidth(w); slackFill:Show()
        slackTxt:SetTextColor(0.6, 0.65, 0.8)
        slackTxt:SetText("GCD " .. ms(n))

      elseif st == "done" then
        -- Already acted this cycle. Shown, but quiet.
        local w = (1 - math.min(1, n / CONFIG.gcd)) * CONFIG.width
        if w < 1 then w = 1 end
        slackFill:SetColorTexture(unpack(C.slkDone))
        slackFill:SetWidth(w); slackFill:Show()
        slackTxt:SetTextColor(0.45, 0.6, 0.52)
        slackTxt:SetText("cast")

      elseif st == "none" then
        slackFill:SetColorTexture(unpack(C.slkNone))
        slackFill:SetWidth(CONFIG.width); slackFill:Show()
        slackTxt:SetTextColor(1, 0.4, 0.4)
        slackTxt:SetText("WEAVE")

      else
        slackFill:SetColorTexture(unpack(C.slkLate))
        slackFill:SetWidth(CONFIG.width); slackFill:Show()
        slackTxt:SetTextColor(1, 0.55, 0.25)
        slackTxt:SetText("late " .. ms(n))
      end

      -- Where the cast in flight lands against the deadline.
      local cs, ce = castWindow()
      if ce and st ~= "none" then
        local rel = (deadline - ce) / span
        local x = (1 - math.max(0, math.min(1, rel))) * CONFIG.width
        slackCast:ClearAllPoints()
        slackCast:SetSize(2, CONFIG.slackH + 4)
        slackCast:SetPoint("CENTER", slackBg, "LEFT", x, 0)
        slackCast:SetColorTexture(ce > deadline and 1 or 1,
                                  ce > deadline and 0.25 or 1,
                                  ce > deadline and 0.2 or 1, 0.9)
        slackCast:Show()
      else
        slackCast:Hide()
      end
    else
      slackBg:Hide(); slackFill:Hide(); slackCast:Hide(); slackTxt:SetText("")
    end
  else
    slackBg:Hide(); slackFill:Hide(); slackCast:Hide(); slackTxt:SetText("")
  end

  if CONFIG.showEws then
    stat[1]:SetTextColor(C.txtEws[1], C.txtEws[2], C.txtEws[3])
    stat[1]:SetText(string.format("eWS  %.2f", ews()))
  else
    stat[1]:SetText("")
  end
  stat[2]:SetText("")
  stat[3]:SetText("")

  stat[4]:SetText("")
  local rt = CONFIG.showRange and rangeText() or ""
  if rt == "" then
    rangeLabel:SetText("")
  else
    local tv = travelTime()
    local extra = (tv and tv > 0) and ("  " .. ms(tv) .. "ms") or ""
    rangeLabel:SetTextColor(C.txtRange[1], C.txtRange[2], C.txtRange[3])
    rangeLabel:SetText(rt .. extra)
  end

  if not CONFIG.showClip then
    clipText:SetText("")
  elseif state.holding then
    -- Warning states keep their own colour. A red clip figure going
    -- user-coloured would hide the one thing it exists to signal.
    clipText:SetTextColor(1, 0.80, 0.20)
    clipText:SetText("WAITING")
  elseif state.lastStall > 0.02 then
    clipText:SetTextColor(1, 0.42, 0.42)
    clipText:SetText("clip " .. ms(state.lastStall) .. "ms")
  elseif state.lastClip > 0.02 then
    clipText:SetTextColor(1, 0.42, 0.42)
    clipText:SetText("clip " .. ms(state.lastClip) .. "ms")
  else
    clipText:SetTextColor(C.txtClip[1], C.txtClip[2], C.txtClip[3])
    clipText:SetText("clean")
  end
end

local lastHostile = 0

local function updateVisibility()
  local t = "target"
  local now = GetTime()
  local hostile = UnitExists(t) and UnitCanAttack("player", t) and not UnitIsDead(t)
  if hostile then lastHostile = now end

  -- Starting a cast counts as engaged. Opening with Aimed Shot happens
  -- before the combat flag lands, and a dim bar during the opener is
  -- exactly when it needs to be readable.
  -- Overrides everything else, including hiding with no target.
  if CONFIG.neverFade then
    lastHostile = now
    holder:Show()
    holder:SetAlpha(1.0)
    return
  end

  local inCast = castEndsAt() ~= nil
  local active = UnitAffectingCombat("player") or inCast

  local since = now - lastHostile

  -- Any cast shows the bar at full opacity, target or not: herbing,
  -- mining, mounting, a res. It doubles as a cast bar for whatever you
  -- are actually doing.
  if inCast then
    holder:Show()
    holder:SetAlpha(1.0)
  elseif hostile then
    holder:Show()
    holder:SetAlpha(active and 1.0 or CONFIG.idleAlpha)
  elseif since < CONFIG.noTargetFade then
    -- Grace window: losing a target mid-fight should not blink the bar
    -- out, so ease down over the fade period instead.
    local k = 1 - (since / CONFIG.noTargetFade)
    local full = active and 1.0 or CONFIG.idleAlpha
    holder:Show()
    holder:SetAlpha(CONFIG.idleAlpha + (full - CONFIG.idleAlpha) * k)
  elseif not CONFIG.hideNoTarget then
    holder:Show(); holder:SetAlpha(CONFIG.idleAlpha)
  else
    holder:Hide()
  end
end

local visAcc = 0
local acc = 0
root:SetScript("OnUpdate", function(self, dt)
  -- Continuous bleed. Nothing else in the addon moves a note.
  if state.pending ~= 0 then
    local step = CONFIG.bleedMax * dt
    local d = state.pending
    if math.abs(d) <= step then
      shiftPlan(d); state.pending = 0
    else
      local piece = (d > 0) and step or -step
      shiftPlan(piece)
      state.pending = d - piece
    end
  end
  -- Stopped means stopped: the whole frame counts as stall.
  if state.holding then state.hold = state.hold + dt end
  updateDistance(GetTime(), dt)

  visAcc = visAcc + dt
  if visAcc > 0.2 then
    visAcc = 0
    updateVisibility()
  end
  acc = acc + dt
  if acc < (1/60) then return end
  acc = 0
  render()
end)

--------------------------------------------------------------------------
-- Events
--------------------------------------------------------------------------

-- Forward declarations. These are DEFINED further down, but the login
-- handler below calls them -- and a Lua function cannot see a local
-- declared after it. Without this they resolve as nil globals, the
-- handler throws, and with scriptErrors off it fails in total silence:
-- no panel, no error, nothing to debug.
local loadSettings, applyScale, registerPanel

root:RegisterEvent("PLAYER_LOGIN")
root:RegisterEvent("UNIT_SPELLCAST_START")
root:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
root:RegisterEvent("START_AUTOREPEAT_SPELL")
root:RegisterEvent("STOP_AUTOREPEAT_SPELL")
root:RegisterEvent("PLAYER_REGEN_ENABLED")
root:RegisterEvent("PLAYER_REGEN_DISABLED")
root:RegisterEvent("PLAYER_TARGET_CHANGED")
root:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")

root:SetScript("OnEvent", function(self, event, ...)
  if event == "PLAYER_LOGIN" then
    resolve()
    loadSettings()
    applyScale()
    applySkin()
    registerPanel()
    if WeaveLineDB and WeaveLineDB.textPos then
      for i = 1, #TEXTS do
        local e = WeaveLineDB.textPos[i]
        if type(e) == "table" then
          local p, rp, x, y = unpack(e)
          textHolder[i]:ClearAllPoints()
          textHolder[i]:SetPoint(p, UIParent, rp, x, y)
        end
      end
    end
    if WeaveLineDB and WeaveLineDB.pipPos then
      for i = 1, #PIPS do
        local e = WeaveLineDB.pipPos[i]
        if type(e) == "table" then
          local p, rp, x, y = unpack(e)
          pipHolder[i]:ClearAllPoints()
          pipHolder[i]:SetPoint(p, UIParent, rp, x, y)
        end
      end
    end
    if WeaveLineDB and WeaveLineDB.pos then
      local p, rp, x, y = unpack(WeaveLineDB.pos)
      holder:ClearAllPoints(); holder:SetPoint(p, UIParent, rp, x, y)
    end

  elseif event == "START_AUTOREPEAT_SPELL" then
    -- The NEXT interval spans a break, so do not measure it -- but keep
    -- the anchor. lastAuto is what the whole movement bar is built on,
    -- and zeroing it here blanked the bar every time you stepped into
    -- melee, because the retry timer re-fires this event repeatedly
    -- while Auto Shot cannot resume.
    state.skipInterval = true

  elseif event == "STOP_AUTOREPEAT_SPELL" then
    -- Deliberately does nothing to the queue. The weave macro toggles
    -- attack every time you step in, and wiping here is what made the
    -- bar go blank mid-fight. The plan is free-running; it keeps going.

  elseif event == "UNIT_SPELLCAST_START" then
    local unit, _, spellID = ...
    if unit ~= "player" then return end
    local nm, now = spellInfo(spellID), GetTime()
    if nm == SPELL.steady or nm == SPELL.multi then
      -- The timeline begins on your first input, not on entering combat,
      -- so the opener lines up with the start of the sequence.
      if not gen.seeded then seedGenerator(now) end
      if nm == SPELL.steady then
        pushActual("steady", now, now + steadyCast())
      else
        pushActual("multi", now, now + multiCast())
        if pip[1] then pip[1].castAt = now end
      end
    end

  elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
    local unit, _, spellID = ...
    if unit ~= "player" then return end
    local nm, now = spellInfo(spellID), GetTime()
    if nm == SPELL.auto then
      if state.lastAuto > 0 then
        local c = now - (state.lastAuto + ews())
        state.lastClip = (c > 0 and c < ews()) and c or 0
      end
      -- An auto fired, so we were outside its minimum range.
      if state.dist and state.dist < CONFIG.meleeRange then
        state.dist, state.fixAt = CONFIG.meleeRange, GetTime()
      end
      state.lastAuto = now
      state.skipInterval = false
      -- Seeded once. Later autos never touch the generator, so committed
      -- notes stay put; alignment is handled by the slew instead.
      if not gen.seeded then seedGenerator(now) end
      pushActual("auto", now - autoCast(), now)

      -- Release the gate. Whatever time was spent held is exactly how
      -- much this shot clipped, which is worth surfacing.
      if CONFIG.gateOnAuto and state.gate then
        -- Pin the gated note exactly onto the line. One expression
        -- covers both directions: positive shift when you clipped and we
        -- held, negative when the shot landed early and the plan was
        -- running ahead. No second mechanism needed.
        local shift = now - state.gate
        state.lastStall  = state.hold
        state.gatePassed = state.gate + shift
        shiftPlan(shift)
        state.hold       = 0
        state.holding    = false
      end

      -- Compare this real auto against the nearest planned one and
      -- retarget the slew. Wrapped to +/- half a cycle so we correct
      -- phase, never jump a whole cycle.
      -- Learn the real interval first, so the grid tracks the rhythm you
      -- actually produce rather than a theoretical one you never hit.
      if state.lastAuto > 0 and not state.skipInterval then
        local iv = now - state.lastAuto
        local e  = ews()
        -- Tight window on purpose. Anything much longer than a clipped
        -- shot is not rhythm, it is a pause -- moving, retargeting, a
        -- dead mob. Averaging those in drags the grid slow and every
        -- note ends up spaced by a number you never actually shoot at.
        if e > 0 and iv > e * 0.9 and iv < e * 1.6 then
          if state.cycleLen then
            state.cycleLen = state.cycleLen + (iv - state.cycleLen) * CONFIG.cycleGain
          else
            state.cycleLen = iv
          end
        end
      end

      if CONFIG.phaseLock then
        local speed = cycleLength()
        local best
        for _, e in ipairs(state.plan) do
          if e.kind == "auto" then
            local d = math.abs(e.t1 - now)
            if not best or d < best.d then best = { d = d, t = e.t1 } end
          end
        end
        if best and speed > 0 then
          -- Wrapped to half a cycle: correct phase, never jump a cycle.
          local err = now - best.t
          err = err - math.floor(err / speed + 0.5) * speed
          -- Low-pass, not a full correction: track the rhythm, do not
          -- adopt the mistake.
          -- Banked, not applied. The bleed below moves it in.
          if math.abs(err) >= CONFIG.phaseDead then
            state.pending = err * CONFIG.phaseGain
          end
          state.lastPhaseErr = err
          if CONFIG.debug then
            print(string.format("|cff88ccffWL|r phase err %sms -> applied %sms",
              ms(err), ms(err * CONFIG.phaseGain)))
          end
        end
      end

      pushActual("auto", now - autoCast(), now)

      -- Release the gate. Whatever time was spent held is exactly how
      -- much this shot clipped, which is worth surfacing.
      if CONFIG.gateOnAuto and state.gate then
        -- Pin the gated note exactly onto the line. One expression
        -- covers both directions: positive shift when you clipped and we
        -- held, negative when the shot landed early and the plan was
        -- running ahead. No second mechanism needed.
        local shift = now - state.gate
        state.lastStall  = state.hold
        state.gatePassed = state.gate + shift
        shiftPlan(shift)
        state.hold       = 0
        state.holding    = false
      end

    elseif nm == SPELL.arcane then
      pushActual("arcane", now, now + CONFIG.arcaneWidth)
      if pip[2] then pip[2].castAt = now end
    end

  elseif event == "COMBAT_LOG_EVENT_UNFILTERED" then
    local _, sub, _, srcGUID, _, _, _, _, _, _, _, a12, a13 = CombatLogGetCurrentEventInfo()
    if srcGUID ~= UnitGUID("player") then return end

    if sub == "SWING_DAMAGE" or sub == "SWING_MISSED" then
      state.impactAt, state.impactDur, state.impactStrong =
        GetTime(), CONFIG.impactMelee, false
      state.lastSwing = GetTime()
      -- A swing landed, so we were inside melee at that instant. This is
      -- the 5-yard fix no item probe provides.
      if state.dist and state.dist > CONFIG.meleeRange then
        state.dist, state.fixAt = CONFIG.meleeRange, GetTime()
      end
      if CONFIG.debug then print("|cff88ccffWL|r impact: melee swing") end
    elseif sub == "SPELL_DAMAGE" or sub == "SPELL_MISSED"
        or sub == "SPELL_CAST_SUCCESS" then
      -- Anniversary sends localized names; Era sends ids. Handle both.
      -- CAST_SUCCESS is included so a Raptor that misses still registers.
      local nm = a13
      if not nm and type(a12) == "number" then nm = spellInfo(a12) end
      if nm == SPELL.raptor then
        state.impactAt, state.impactDur, state.impactStrong =
          GetTime(), CONFIG.impactRaptor, true
        -- Raptor rides the swing, so it consumes one.
        state.lastSwing = GetTime()
        if CONFIG.debug then print("|cff88ccffWL|r impact: raptor (" .. sub .. ")") end
      end
    end

  elseif event == "PLAYER_TARGET_CHANGED" then
    updateVisibility()

  elseif event == "PLAYER_REGEN_DISABLED" then
    updateVisibility()

  elseif event == "PLAYER_REGEN_ENABLED" then
    state.lastClip = 0
    -- Drop out of combat and the next opener re-seeds from scratch.
    gen.seeded = false
    wipe(state.plan); wipe(state.actual)
    updateVisibility()
  end
end)


--------------------------------------------------------------------------
-- Options panel
--
-- Self-contained: reads and writes CONFIG, then calls layout(). Every
-- API call that differs between client versions is pcall-guarded, so a
-- missing function degrades to "no panel" rather than breaking the bar.
--------------------------------------------------------------------------

local DB_KEYS = {
  "showRange", "pips", "showEws", "showClip",
  "meleeLane", "uiScale", "neverFade",
  "skin", "fontFace", "fontSize",
  "rangeSize", "ewsSize", "clipSize",
  "posEws", "posClip", "posRange", "width", "pipSize", "pipScale",
  "showMulti", "showArcane", "showKC", "kcGlow", "borderMode",
  "pipBorder", "pipBorderSz", "freeText",
}
-- Every colour the bar can actually show. The short list left states
-- like the orange clip warning unreachable from the panel.
local DB_COLORS = {
  { "mvCast",   "Casting"          },
  { "mvOver",   "Cast will clip"   },
  { "mvChan",   "Channelling"      },
  { "mvDone",   "Cast finished"    },
  { "mvFree",   "Melee window"     },
  { "mvWait",   "Downtime"         },
  { "mvHold",   "Auto shot"        },
  { "mvLate",   "Auto overdue"     },
  { "mvBack",   "Lane background"  },
  { "swingUp",  "Raptor ready"     },
  { "swingCd",  "Raptor on CD"     },
  { "track",    "Bar background"   },
  { "rngMelee", "Range: melee"     },
  { "rngStep",  "Range: one step"  },
  { "rngRanged","Range: ranged"    },
  { "rngFar",   "Range: too far"   },
  { "pipEdge",  "Icon outline"     },
  { "kcEdge",   "KC border glow"   },
}

local function saveSettings()
  WeaveLineDB = WeaveLineDB or {}
  WeaveLineDB.cfg = WeaveLineDB.cfg or {}
  for _, k in ipairs(DB_KEYS) do WeaveLineDB.cfg[k] = CONFIG[k] end
  WeaveLineDB.colors = WeaveLineDB.colors or {}
  for _, e in ipairs(DB_COLORS) do
    local c = C[e[1]]
    if c then WeaveLineDB.colors[e[1]] = { c[1], c[2], c[3], c[4] or 1 } end
  end
end

function loadSettings()
  if not WeaveLineDB then return end
  if WeaveLineDB.cfg then
    for _, k in ipairs(DB_KEYS) do
      if WeaveLineDB.cfg[k] ~= nil then CONFIG[k] = WeaveLineDB.cfg[k] end
    end
  end
  if WeaveLineDB.colors then
    for k, v in pairs(WeaveLineDB.colors) do
      if C[k] and type(v) == "table" then
        C[k][1], C[k][2], C[k][3] = v[1], v[2], v[3]
        C[k][4] = v[4] or 1
      end
    end
  end
end

function applyScale()
  local sc = CONFIG.uiScale or 1
  if sc < 0.5 then sc = 0.5 elseif sc > 2.0 then sc = 2.0 end
  pcall(function() holder:SetScale(sc) end)
end

-- A standalone window: movable, resizable, and the content scrolls. The
-- Blizzard options page cannot grow, which is why the panel kept
-- outrunning it every time something was added.
local function buildWindow()
  local win = CreateFrame("Frame", "WeaveLineWindow", UIParent)
  win:SetSize(620, 520)
  win:SetPoint("CENTER")
  win:SetFrameStrata("DIALOG")
  win:SetMovable(true); win:SetResizable(true)
  win:EnableMouse(true)
  pcall(function() win:SetMinResize(420, 260) end)
  pcall(function() win:SetResizeBounds(420, 260, 1200, 900) end)
  win:Hide()

  local bg = win:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints(win)
  bg:SetColorTexture(0.05, 0.06, 0.08, 0.96)

  local bar = CreateFrame("Frame", nil, win)
  bar:SetPoint("TOPLEFT"); bar:SetPoint("TOPRIGHT")
  bar:SetHeight(26)
  bar:EnableMouse(true)
  bar:RegisterForDrag("LeftButton")
  bar:SetScript("OnDragStart", function() win:StartMoving() end)
  bar:SetScript("OnDragStop",  function() win:StopMovingOrSizing() end)
  local barbg = bar:CreateTexture(nil, "ARTWORK")
  barbg:SetAllPoints(bar)
  barbg:SetColorTexture(0.12, 0.13, 0.17, 1)

  local title = bar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  title:SetPoint("LEFT", 10, 0)
  title:SetText("Jabe's TBC Hunter WeaveLine")

  local close = CreateFrame("Button", nil, bar)
  close:SetSize(22, 22)
  close:SetPoint("RIGHT", -4, 0)
  local ct = close:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  ct:SetPoint("CENTER"); ct:SetText("x")
  close:SetScript("OnClick", function() win:Hide() end)

  local grip = CreateFrame("Button", nil, win)
  grip:SetSize(16, 16)
  grip:SetPoint("BOTTOMRIGHT", -2, 2)
  local gt = grip:CreateTexture(nil, "OVERLAY")
  gt:SetAllPoints(grip)
  gt:SetColorTexture(0.5, 0.52, 0.6, 0.8)
  grip:SetScript("OnMouseDown", function() win:StartSizing("BOTTOMRIGHT") end)
  grip:SetScript("OnMouseUp",   function() win:StopMovingOrSizing() end)

  -- Clipping viewport, with the content scrolled inside it.
  local view = CreateFrame("Frame", nil, win)
  view:SetPoint("TOPLEFT", 0, -26)
  view:SetPoint("BOTTOMRIGHT", -4, 4)
  view:EnableMouseWheel(true)
  pcall(function() view:SetClipsChildren(true) end)

  local panel = CreateFrame("Frame", "WeaveLineOptionsPanel", view)
  panel:SetPoint("TOPLEFT")
  panel:SetSize(600, 900)

  local scroll = 0
  view:SetScript("OnMouseWheel", function(_, delta)
    local maxs = math.max(0, (panel.contentH or 900) - view:GetHeight())
    scroll = math.min(maxs, math.max(0, scroll - delta * 40))
    panel:SetPoint("TOPLEFT", 0, scroll)
  end)
  win.view, win.panel = view, panel

  local sub = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
  sub:SetPoint("TOPLEFT", 16, -10)
  sub:SetText("Shift-drag the bar or any icon to move it. "
    .. "Mouse wheel scrolls.  /wl for all commands.")

  local y = -34

  -- Built from primitives, not XML templates. The Interface* and Options*
  -- templates were removed in newer clients, and CreateFrame throws on a
  -- missing template -- which is why the category never registered at all.
  -- Two columns throughout. The panel does not scroll, so the content
  -- has to fit; a ScrollFrame would mean another version-specific
  -- template and those have not been kind to us.
  local ccol, kcol = 0, 0
  local function check(label, key, tip)
    local cb = CreateFrame("CheckButton", nil, panel)
    cb:SetSize(24, 24)
    cb:SetPoint("TOPLEFT", 18 + (ccol % 2) * 290, y)
    cb:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
    cb:SetPushedTexture("Interface\\Buttons\\UI-CheckBox-Down")
    cb:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight", "ADD")
    cb:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
    cb:SetChecked(CONFIG[key] and true or false)

    local t = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    t:SetPoint("LEFT", cb, "RIGHT", 4, 0)
    t:SetText(label)

    cb:SetScript("OnClick", function(self)
      CONFIG[key] = self:GetChecked() and true or false
      layout(); recomputeGeometry(); saveSettings()
    end)
    if tip then
      cb:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(tip, 1, 1, 1, 1, true); GameTooltip:Show()
      end)
      cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    ccol = ccol + 1
    if ccol % 2 == 0 then y = y - 24 end
  end

  local function header(text)
    if ccol % 2 ~= 0 then ccol = 0; y = y - 24 end
    if kcol % 2 ~= 0 then kcol = 0; y = y - 26 end
    y = y - 6
    local h = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    h:SetPoint("TOPLEFT", 16, y - 8)
    h:SetText(text)
    -- A hairline under each heading, so sections read as sections.
    local rule = panel:CreateTexture(nil, "ARTWORK")
    rule:SetPoint("TOPLEFT", 16, y - 24)
    rule:SetSize(560, 1)
    rule:SetColorTexture(1, 1, 1, 0.10)
    y = y - 32
  end

  header("Display")
  check("Melee swing bar",            "meleeLane", "Lower lane: melee swing timer.")
  check("Range finder",               "showRange", "Range readout and the coloured border.")
  check("Icons (master)",   "pips",       "Turn all three icons off at once.")
  check("Multi-Shot icon",  "showMulti",  "")
  check("Arcane Shot icon", "showArcane", "")
  check("Kill Command icon","showKC",     "Glows and pulses when castable.")
  check("Icon outlines",    "pipBorder",  "A border around each icon.")
  check("eWS readout",                "showEws",   "Effective weapon speed, bottom left.")
  check("Clip readout",               "showClip",  "clip / clean, top right.")
  check("Never fade",                 "neverFade", "Always fully visible. Ignores combat state and target.")

  header("Style")

  -- One row per label: a size slider and its colour swatch together, so
  -- everything about a piece of text lives in one place.
  local function textRow(label, sizeKey, colKey, xoff)
    local sl = CreateFrame("Slider", nil, panel)
    sl:SetOrientation("HORIZONTAL")
    sl:SetSize(150, 15)
    sl:SetPoint("TOPLEFT", xoff, y - 14)
    sl:SetHitRectInsets(0, 0, -5, -5)
    sl:SetMinMaxValues(6, 28)
    sl:SetValueStep(1)
    if sl.SetObeyStepOnDrag then sl:SetObeyStepOnDrag(true) end
    sl:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
    local bg = sl:CreateTexture(nil, "BACKGROUND")
    bg:SetPoint("TOPLEFT", 0, -5)
    bg:SetPoint("BOTTOMRIGHT", 0, 5)
    bg:SetColorTexture(0, 0, 0, 0.55)

    local cap = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    cap:SetPoint("BOTTOMLEFT", sl, "TOPLEFT", 0, 3)
    local function relabel(v) cap:SetText(label .. "   " .. math.floor(v) .. "px") end
    sl:SetValue(CONFIG[sizeKey] or 12)
    relabel(CONFIG[sizeKey] or 12)
    sl:SetScript("OnValueChanged", function(self, val)
      val = math.floor(val + 0.5)
      CONFIG[sizeKey] = val
      relabel(val); applyFont(); saveSettings()
    end)

    local b = CreateFrame("Button", nil, panel)
    b:SetSize(16, 16)
    b:SetPoint("LEFT", sl, "RIGHT", 8, 0)
    local bd = b:CreateTexture(nil, "BACKGROUND")
    bd:SetPoint("TOPLEFT", -1, 1); bd:SetPoint("BOTTOMRIGHT", 1, -1)
    bd:SetColorTexture(0, 0, 0, 1)
    local sw = b:CreateTexture(nil, "ARTWORK")
    sw:SetAllPoints(b)
    local function paint()
      local c = C[colKey]
      if c then sw:SetColorTexture(c[1], c[2], c[3], 1) end
    end
    paint()
    b:SetScript("OnClick", function()
      local c = C[colKey]
      if not c then return end
      local r0, g0, b0 = c[1], c[2], c[3]
      local function apply(nr, ng, nb)
        c[1], c[2], c[3] = nr, ng, nb; paint(); saveSettings()
      end
      local function pick()
        local nr, ng, nb
        if ColorPickerFrame.GetColorRGB then
          nr, ng, nb = ColorPickerFrame:GetColorRGB()
        end
        if nr then apply(nr, ng, nb) end
      end
      if ColorPickerFrame.SetupColorPickerAndShow then
        ColorPickerFrame:SetupColorPickerAndShow({
          r = r0, g = g0, b = b0, hasOpacity = false,
          swatchFunc = pick, cancelFunc = function() apply(r0, g0, b0) end })
      else
        ColorPickerFrame.func = pick
        ColorPickerFrame.cancelFunc = function() apply(r0, g0, b0) end
        ColorPickerFrame.hasOpacity = false
        ColorPickerFrame.previousValues = { r0, g0, b0 }
        ColorPickerFrame:Hide()
        pcall(function() ColorPickerFrame:SetColorRGB(r0, g0, b0) end)
        ColorPickerFrame:Show()
      end
    end)
  end

  local function cycler(label, key, list, onChange)
    local b = CreateFrame("Button", nil, panel)
    b:SetSize(96, 22)
    b:SetPoint("TOPLEFT", 22 + (kcol % 2) * 290, y)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(b)
    bg:SetColorTexture(0.16, 0.17, 0.21, 1)
    local bt = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    bt:SetPoint("CENTER", b, "CENTER", 0, 0)
    local lt = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    lt:SetPoint("LEFT", b, "RIGHT", 8, 0)
    lt:SetText(label)
    local function show() bt:SetText(tostring(CONFIG[key])) end
    show()
    b:SetScript("OnClick", function()
      local i = 1
      for n, v in ipairs(list) do
        if v == CONFIG[key] then i = n break end
      end
      CONFIG[key] = list[(i % #list) + 1]
      show(); onChange(); saveSettings()
    end)
    kcol = kcol + 1
    if kcol % 2 == 0 then y = y - 26 end
    return b
  end

  local skinNames = {}
  for _, sk in ipairs(SKINS) do skinNames[#skinNames+1] = sk.name end
  cycler("Skin", "skin", skinNames, applySkin)
  cycler("Border shows", "borderMode", { "kc", "range", "off" }, function()
    layout()
  end)

  -- A real dropdown, built from primitives. UIDropDownMenuTemplate is
  -- exactly the sort of template this client has already been missing,
  -- so this is a button plus a scrollable list of buttons -- and each row
  -- previews itself in its own font, which is the point of having 30.
  do
    -- Claim a whole row. Without this the dropdown drew at the same y as
    -- the Skin cycler, which is why its value sat on top of the label.
    if kcol % 2 ~= 0 then kcol = 0; y = y - 26 end

    local ROWS, ROWH = 12, 16
    local btn = CreateFrame("Button", nil, panel)
    btn:SetSize(150, 22)
    btn:SetPoint("TOPLEFT", 22, y)
    local bbg = btn:CreateTexture(nil, "BACKGROUND")
    bbg:SetAllPoints(btn)
    bbg:SetColorTexture(0.16, 0.17, 0.21, 1)
    local bl = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    bl:SetPoint("LEFT", btn, "LEFT", 6, 0)
    local arrow = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    arrow:SetPoint("RIGHT", btn, "RIGHT", -6, 0)
    arrow:SetText("v")
    local lt = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    lt:SetPoint("LEFT", btn, "RIGHT", 8, 0)
    lt:SetText("Font")

    local pop = CreateFrame("Frame", nil, panel)
    pop:SetSize(150, ROWS * ROWH + 8)
    pop:SetPoint("TOPLEFT", btn, "BOTTOMLEFT", 0, -2)
    pop:SetFrameStrata("DIALOG")
    pop:EnableMouseWheel(true)
    pop:Hide()
    local pbg = pop:CreateTexture(nil, "BACKGROUND")
    pbg:SetAllPoints(pop)
    pbg:SetColorTexture(0.06, 0.07, 0.09, 0.98)

    local names, off, rows = {}, 0, {}
    local function paint()
      bl:SetText(tostring(CONFIG.fontFace))
      for i = 1, ROWS do
        local n = names[i + off]
        local r = rows[i]
        if n then
          r:Show()
          local pth = (fontPaths(n) or {})[1]
          local done = false
          if pth then
            local ok = pcall(function() r.txt:SetFont(pth, 12, "OUTLINE") end)
            done = ok and (r.txt:GetFont() == pth)
          end
          if not done then
            pcall(function()
              r.txt:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")
            end)
          end
          r.txt:SetText(n)
          r.bg:SetColorTexture(0, 0, 0, (n == CONFIG.fontFace) and 0.55 or 0)
          r.name = n
        else
          r:Hide()
        end
      end
    end

    for i = 1, ROWS do
      local r = CreateFrame("Button", nil, pop)
      r:SetSize(142, ROWH)
      r:SetPoint("TOPLEFT", 4, -4 - (i - 1) * ROWH)
      r.bg = r:CreateTexture(nil, "BACKGROUND")
      r.bg:SetAllPoints(r)
      -- MUST inherit a template. A template-less fontstring has no font
      -- object, and calling SetText on it before SetFont throws.
      r.txt = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
      r.txt:SetPoint("LEFT", r, "LEFT", 4, 0)
      r:SetScript("OnClick", function(self)
        if not self.name then return end
        CONFIG.fontFace = self.name
        applyFont(); saveSettings(); paint(); pop:Hide()
      end)
      r:SetScript("OnEnter", function(self)
        if self.name ~= CONFIG.fontFace then self.bg:SetColorTexture(1,1,1,0.12) end
      end)
      r:SetScript("OnLeave", function(self)
        self.bg:SetColorTexture(0, 0, 0, (self.name == CONFIG.fontFace) and 0.55 or 0)
      end)
      rows[i] = r
    end

    pop:SetScript("OnMouseWheel", function(_, delta)
      off = off - delta * 3
      if off < 0 then off = 0 end
      local maxOff = math.max(0, #names - ROWS)
      if off > maxOff then off = maxOff end
      paint()
    end)

    btn:SetScript("OnClick", function()
      if pop:IsShown() then pop:Hide() return end
      names = fontList()
      off = 0
      for i, n in ipairs(names) do
        if n == CONFIG.fontFace then
          off = math.max(0, math.min(i - 3, #names - ROWS))
          break
        end
      end
      paint()
      pop:Show()
    end)

    names = fontList()
    paint()
    kcol = 0
    y = y - 28
  end

  textRow("State label", "fontSize",  "txtState",  22)
  textRow("Range",       "rangeSize", "txtRange", 290)
  y = y - 42
  textRow("eWS",         "ewsSize",   "txtEws",    22)
  textRow("Clip",        "clipSize",  "txtClip",  290)
  y = y - 42

  header("Positions")

  check("Free-position the readouts", "freeText",
        "Shift-drag eWS, Clip and Range anywhere. The anchor grid below "
        .. "is ignored while this is on.")

  do
    -- Pick an element, then click a dot. Everything here is plain
    -- frames and textures -- the same primitives as the colour swatches.
    local ELEMS = {
      { "eWS",         "posEws"   },
      { "Clip",        "posClip"  },
      { "Range",       "posRange" },
    }
    local sel = 1
    local elemBtns, dots = {}, {}

    local function refresh()
      for i, b in ipairs(elemBtns) do
        b.bg:SetColorTexture(i == sel and 0.30 or 0.16,
                             i == sel and 0.34 or 0.17,
                             i == sel and 0.44 or 0.21, 1)
      end
      local key = ELEMS[sel][2]
      for name, d in pairs(dots) do
        local on = (CONFIG[key] == name)
        d.tex:SetColorTexture(on and 1 or 0.85, on and 0.25 or 0.20,
                              on and 0.25 or 0.20, on and 1 or 0.45)
        d:SetSize(on and 12 or 9, on and 12 or 9)
      end
    end

    for i, e in ipairs(ELEMS) do
      local b = CreateFrame("Button", nil, panel)
      b:SetSize(88, 18)
      b:SetPoint("TOPLEFT", 22 + (i - 1) * 94, y)
      b.bg = b:CreateTexture(nil, "BACKGROUND")
      b.bg:SetAllPoints(b)
      local t = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      t:SetPoint("CENTER")
      t:SetText(e[1])
      b:SetScript("OnClick", function() sel = i; refresh() end)
      elemBtns[i] = b
    end
    y = y - 26

    -- The bar, drawn to scale-ish, with the 8 anchor points around it.
    local bw, bh = 190, 26
    local box = CreateFrame("Frame", nil, panel)
    box:SetSize(bw, bh)
    box:SetPoint("TOPLEFT", 90, y - 26)
    local bt = box:CreateTexture(nil, "BACKGROUND")
    bt:SetAllPoints(box)
    bt:SetColorTexture(0.20, 0.21, 0.26, 1)

    local SPOTS = {
      TOPLEFT     = { "TOPLEFT",     0,   6 },
      TOP         = { "TOP",         0,   6 },
      TOPRIGHT    = { "TOPRIGHT",    0,   6 },
      LEFT        = { "LEFT",       -8,   0 },
      RIGHT       = { "RIGHT",       8,   0 },
      BOTTOMLEFT  = { "BOTTOMLEFT",  0,  -6 },
      BOTTOM      = { "BOTTOM",      0,  -6 },
      BOTTOMRIGHT = { "BOTTOMRIGHT", 0,  -6 },
    }
    for _, name in ipairs(ANCHOR_ORDER) do
      local sp = SPOTS[name]
      local d = CreateFrame("Button", nil, panel)
      d:SetSize(9, 9)
      d:SetPoint("CENTER", box, sp[1], sp[2], sp[3])
      d.tex = d:CreateTexture(nil, "OVERLAY")
      d.tex:SetAllPoints(d)
      d:SetScript("OnClick", function()
        CONFIG[ELEMS[sel][2]] = name
        layout(); refresh(); saveSettings()
      end)
      d:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(name, 1, 1, 1)
        GameTooltip:Show()
      end)
      d:SetScript("OnLeave", function() GameTooltip:Hide() end)
      dots[name] = d
    end
    refresh()
    y = y - bh - 24
  end

  header("Size")

  do
    local wsl = CreateFrame("Slider", nil, panel)
    wsl:SetOrientation("HORIZONTAL")
    wsl:SetSize(210, 17)
    wsl:SetPoint("TOPLEFT", 22, y - 6)
    wsl:SetHitRectInsets(0, 0, -6, -6)
    wsl:SetMinMaxValues(200, 900)
    wsl:SetValueStep(5)
    if wsl.SetObeyStepOnDrag then wsl:SetObeyStepOnDrag(true) end
    wsl:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
    local wbg = wsl:CreateTexture(nil, "BACKGROUND")
    wbg:SetPoint("TOPLEFT", 0, -6)
    wbg:SetPoint("BOTTOMRIGHT", 0, 6)
    wbg:SetColorTexture(0, 0, 0, 0.55)
    local wtx = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    wtx:SetPoint("BOTTOM", wsl, "TOP", 0, 4)
    local function wlabel(v)
      wtx:SetText("Bar length: " .. math.floor(v) .. "px")
    end
    wsl:SetValue(CONFIG.width or 475)
    wlabel(CONFIG.width or 475)
    wsl:SetScript("OnValueChanged", function(self, val)
      val = math.floor(val / 5 + 0.5) * 5
      CONFIG.width = val
      wlabel(val)
      layout(); recomputeGeometry(); saveSettings()
    end)
  end

  -- Scale sits beside bar length rather than under it.
  local sl = CreateFrame("Slider", nil, panel)
  sl:SetOrientation("HORIZONTAL")
  sl:SetSize(210, 17)
  sl:SetPoint("TOPLEFT", 290, y - 6)
  sl:SetHitRectInsets(0, 0, -6, -6)
  sl:SetMinMaxValues(0.5, 2.0)
  sl:SetValueStep(0.05)
  if sl.SetObeyStepOnDrag then sl:SetObeyStepOnDrag(true) end
  sl:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")

  local sbg = sl:CreateTexture(nil, "BACKGROUND")
  sbg:SetPoint("TOPLEFT", 0, -6)
  sbg:SetPoint("BOTTOMRIGHT", 0, 6)
  sbg:SetColorTexture(0, 0, 0, 0.55)

  local slText = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
  slText:SetPoint("BOTTOM", sl, "TOP", 0, 4)
  local function scaleLabel(v)
    slText:SetText(string.format("Scale: %d%%", math.floor(v * 100 + 0.5)))
  end
  sl:SetValue(CONFIG.uiScale or 1)
  scaleLabel(CONFIG.uiScale or 1)
  sl:SetScript("OnValueChanged", function(self, val)
    val = math.floor(val * 20 + 0.5) / 20
    CONFIG.uiScale = val
    scaleLabel(val); applyScale(); saveSettings()
  end)
  y = y - 46

  do
    local function mini(label, key, lo, hi, step, xoff, fmt)
      local sl2 = CreateFrame("Slider", nil, panel)
      sl2:SetOrientation("HORIZONTAL")
      sl2:SetSize(210, 17)
      sl2:SetPoint("TOPLEFT", xoff, y - 6)
      sl2:SetHitRectInsets(0, 0, -6, -6)
      sl2:SetMinMaxValues(lo, hi)
      sl2:SetValueStep(step)
      if sl2.SetObeyStepOnDrag then sl2:SetObeyStepOnDrag(true) end
      sl2:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
      local bg2 = sl2:CreateTexture(nil, "BACKGROUND")
      bg2:SetPoint("TOPLEFT", 0, -6)
      bg2:SetPoint("BOTTOMRIGHT", 0, 6)
      bg2:SetColorTexture(0, 0, 0, 0.55)
      local tx2 = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
      tx2:SetPoint("BOTTOM", sl2, "TOP", 0, 4)
      local function lab(v) tx2:SetText(string.format(fmt, v)) end
      sl2:SetValue(CONFIG[key] or lo)
      lab(CONFIG[key] or lo)
      sl2:SetScript("OnValueChanged", function(self, val)
        val = math.floor(val / step + 0.5) * step
        CONFIG[key] = val
        lab(val); layout(); saveSettings()
      end)
    end

    mini("Icon size",  "pipSize",  12, 64,  1,    22, "Icon size: %d")
    mini("Icon scale", "pipScale", 0.5, 2.0, 0.05, 290, "Icon scale: %.2f")
    y = y - 46
    mini("KC glow", "kcGlow", 0.2, 1.0, 0.05, 22, "Kill Command glow: %.2f")
    mini("Outline", "pipBorderSz", 0, 6, 1, 290, "Icon outline: %dpx")
    y = y - 46
  end

  header("Colours")
  local col = 0
  for _, e in ipairs(DB_COLORS) do
    local key, label = e[1], e[2]
    local b = CreateFrame("Button", nil, panel)
    b:SetSize(18, 18)
    b:SetPoint("TOPLEFT", 22 + (col % 3) * 200, y)
    local bd = b:CreateTexture(nil, "BACKGROUND")
    bd:SetPoint("TOPLEFT", -1, 1); bd:SetPoint("BOTTOMRIGHT", 1, -1)
    bd:SetColorTexture(0, 0, 0, 1)
    local sw = b:CreateTexture(nil, "ARTWORK")
    sw:SetAllPoints(b)
    local function paint()
      local c = C[key]
      if c then sw:SetColorTexture(c[1], c[2], c[3], 1) end
    end
    paint()

    local t = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    t:SetPoint("LEFT", b, "RIGHT", 6, 0)
    t:SetText(label)

    b:SetScript("OnClick", function()
      local c = C[key]
      if not c then return end
      local r0, g0, b0 = c[1], c[2], c[3]
      local function apply(nr, ng, nb)
        c[1], c[2], c[3] = nr, ng, nb
        paint(); saveSettings()
      end
      local function pick()
        local nr, ng, nb
        if ColorPickerFrame.GetColorRGB then
          nr, ng, nb = ColorPickerFrame:GetColorRGB()
        end
        if nr then apply(nr, ng, nb) end
      end
      if ColorPickerFrame.SetupColorPickerAndShow then
        ColorPickerFrame:SetupColorPickerAndShow({
          r = r0, g = g0, b = b0, hasOpacity = false,
          swatchFunc = pick,
          cancelFunc = function() apply(r0, g0, b0) end,
        })
      else
        ColorPickerFrame.func       = pick
        ColorPickerFrame.cancelFunc = function() apply(r0, g0, b0) end
        ColorPickerFrame.hasOpacity = false
        ColorPickerFrame.previousValues = { r0, g0, b0 }
        ColorPickerFrame:Hide()
        pcall(function() ColorPickerFrame:SetColorRGB(r0, g0, b0) end)
        ColorPickerFrame:Show()
      end
    end)

    col = col + 1
    if col % 3 == 0 then y = y - 23 end
  end

  panel.contentH = math.abs(y) + 40
  panel:SetSize(600, panel.contentH)
  return win
end

-- The Blizzard page becomes a launcher: one button that opens the real
-- window. Everything hard about the options system -- growing content,
-- resizing, scrolling -- is ours to control rather than theirs.
function registerPanel()
  local ok, win = pcall(buildWindow)
  if not ok then
    print("|cffff4444WeaveLine options failed to build:|r " .. tostring(win))
    return
  end
  WeaveLineWindowFrame = win

  local launcher = CreateFrame("Frame", "WeaveLineLauncher", UIParent)
  launcher.name = "Jabe's WeaveLine"
  launcher:Hide()
  launcher.OnCommit  = function() end
  launcher.OnDefault = function() end
  launcher.OnRefresh = function() end

  local t = launcher:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  t:SetPoint("TOPLEFT", 16, -16)
  t:SetText("Jabe's TBC Hunter WeaveLine")
  local d = launcher:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
  d:SetPoint("TOPLEFT", t, "BOTTOMLEFT", 0, -8)
  d:SetText("Settings open in their own resizable window.")

  local b = CreateFrame("Button", nil, launcher)
  b:SetSize(180, 26)
  b:SetPoint("TOPLEFT", 18, -70)
  local bbg = b:CreateTexture(nil, "BACKGROUND")
  bbg:SetAllPoints(b)
  bbg:SetColorTexture(0.18, 0.20, 0.26, 1)
  local bt = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  bt:SetPoint("CENTER")
  bt:SetText("Open WeaveLine settings")
  b:SetScript("OnClick", function() win:Show() end)

  if Settings and Settings.RegisterCanvasLayoutCategory then
    local ok2, cat = pcall(function()
      local c = Settings.RegisterCanvasLayoutCategory(launcher, "Jabe's WeaveLine")
      Settings.RegisterAddOnCategory(c)
      return c
    end)
    if ok2 and cat then WeaveLineOptionsCategory = cat return end
    print("|cffff4444WeaveLine Settings registration failed:|r " .. tostring(cat))
  end
  if InterfaceOptions_AddCategory then
    if pcall(InterfaceOptions_AddCategory, launcher) then return end
  end
  print("|cffff4444WeaveLine: no options system found; use /wl options.|r")
end

--------------------------------------------------------------------------
-- Slash
--------------------------------------------------------------------------

SLASH_WEAVELINE1 = "/weaveline"
SLASH_WEAVELINE2 = "/wl"
SlashCmdList["WEAVELINE"] = function(msg)
  local cmd, rest = msg:match("^(%S*)%s*(.-)$")
  cmd = (cmd or ""):lower(); local v = tonumber(rest)

  if cmd == "width" and v then
    CONFIG.width = v; root:SetWidth(v); innerW = v - CONFIG.pad*2
    trackTop:SetWidth(innerW); trackBot:SetWidth(innerW); hair:SetWidth(innerW)
    recomputeGeometry()
  elseif cmd == "cycles" and v then CONFIG.cycles = v; recomputeGeometry()
  elseif cmd == "linepos" and v then CONFIG.linePos = v; recomputeGeometry()
  elseif cmd == "linewidth" and v then
    CONFIG.lineWidth = v
    nowTop:SetSize(v, CONFIG.laneH + 4); nowBot:SetSize(v, CONFIG.laneH + 4)
  elseif cmd == "ticks" then CONFIG.ticks = not CONFIG.ticks
  elseif cmd == "horizon" then
    CONFIG.horizonMark = not CONFIG.horizonMark
    print("|cff88ccffWL|r horizon mark " .. tostring(CONFIG.horizonMark))
  elseif cmd == "ghost" and v then
    CONFIG.ghostAlpha = v
    print(string.format("|cff88ccffWL|r speculation drawn at %.0f%%", v * 100))
  elseif cmd == "idlestyle" then
    CONFIG.idleStyle = (CONFIG.idleStyle == "tail" and "block")
                    or (CONFIG.idleStyle == "block" and "hidden") or "tail"
    print("|cff88ccffWL|r idle style: " .. CONFIG.idleStyle)
  elseif cmd == "idlemin" and v then
    CONFIG.idleMin = v
    print("|cff88ccffWL|r hiding idles under " .. ms(v) .. "ms")
  elseif cmd == "idlealphatail" and v then
    CONFIG.idleTailAlpha = v
  elseif cmd == "sepbright" and v then
    CONFIG.sepBright = v
  elseif cmd == "sepoverhang" and v then
    CONFIG.sepOverhang = v
    print("|cff88ccffWL|r separator overhang " .. v .. "px")

  elseif cmd == "pips" then
    CONFIG.pips = not CONFIG.pips; layout()
    print("|cff88ccffWL|r instant pips " .. tostring(CONFIG.pips))
  elseif cmd == "pipsize" and v then
    CONFIG.pipSize = v; layout()

  elseif cmd == "castbar" then
    CONFIG.castBar = not CONFIG.castBar
    print("|cff88ccffWL|r live cast overlay " .. tostring(CONFIG.castBar))

  elseif cmd == "casttick" then
    CONFIG.castTick = not CONFIG.castTick
    print("|cff88ccffWL|r cast completion tick " .. tostring(CONFIG.castTick))

  elseif cmd == "estimate" then
    CONFIG.estimate = not CONFIG.estimate
    state.dist = nil
    print("|cff88ccffWL|r distance estimator " .. tostring(CONFIG.estimate))

  elseif cmd == "edgefade" and v then
    CONFIG.edgeFade = v; layout()
    print("|cff88ccffWL|r edge fade " .. v .. "px")
  elseif cmd == "bleed" and v then
    CONFIG.bleedMax = v
    print(string.format("|cff88ccffWL|r corrections bled at %.0f%% of scroll speed",
      v * 100))
  elseif cmd == "cyclegain" and v then
    CONFIG.cycleGain = v
    print(string.format("|cff88ccffWL|r rhythm learning rate %.2f", v))
  elseif cmd == "regrid" then
    state.cycleLen = nil
    print("|cff88ccffWL|r relearning your interval from scratch")
  elseif cmd == "gain" and v then
    CONFIG.phaseGain = v
    print(string.format("|cff88ccffWL|r phase gain %.2f (1.0 = adopt your timing)", v))
  elseif cmd == "deadzone" and v then
    CONFIG.phaseDead = v
    print("|cff88ccffWL|r phase deadzone " .. ms(v) .. "ms")

  elseif cmd == "reach" then
    CONFIG.markReach = not CONFIG.markReach
    print("|cff88ccffWL|r reachability marking " .. tostring(CONFIG.markReach))
  elseif cmd == "runspeed" and v then
    CONFIG.runSpeed = v
    print("|cff88ccffWL|r run speed " .. v .. " yd/s")

  elseif cmd == "gate" then
    CONFIG.gateOnAuto = not CONFIG.gateOnAuto
    if not CONFIG.gateOnAuto then
      state.holding, state.stallStarted = false, false
    end
    print("|cff88ccffWL|r hold-at-auto " .. tostring(CONFIG.gateOnAuto))
  elseif cmd == "gatemax" and v then
    CONFIG.gateMax = v
    print("|cff88ccffWL|r max stall " .. v .. "s")

  elseif cmd == "phaselock" then
    CONFIG.phaseLock = not CONFIG.phaseLock
    if CONFIG.phaseLock and CONFIG.gateOnAuto then
      print("|cff88ccffWL|r note: gate is on, so phase lock stays idle")
    end
    print("|cff88ccffWL|r phase lock " .. tostring(CONFIG.phaseLock))

  elseif cmd == "seps" then
    CONFIG.separators = not CONFIG.separators
    print("|cff88ccffWL|r input separators " .. tostring(CONFIG.separators))
  elseif cmd == "sepwidth" and v then
    CONFIG.sepWidth = v
  elseif cmd == "fullbar" then
    CONFIG.fullBar = not CONFIG.fullBar
    print("|cff88ccffWL|r " .. (CONFIG.fullBar
      and "each state fills the bar" or "shared cycle scale"))

  elseif cmd == "nowline" then
    CONFIG.nowLine = not CONFIG.nowLine; layout()
    print("|cff88ccffWL|r now line " .. tostring(CONFIG.nowLine))

  elseif cmd == "weavebar" then
    CONFIG.weaveBar = not CONFIG.weaveBar
    print("|cff88ccffWL|r top lane: "
      .. (CONFIG.weaveBar and "movement window" or "rotation timeline"))

  elseif cmd == "slack" then
    CONFIG.slackMeter = not CONFIG.slackMeter; layout()
    print("|cff88ccffWL|r slack meter " .. tostring(CONFIG.slackMeter))
  elseif cmd == "slackh" and v then
    CONFIG.slackH = v; layout()

  elseif cmd == "melee" then
    CONFIG.meleeLane = not CONFIG.meleeLane
    layout(); recomputeGeometry()
    print("|cff88ccffWL|r melee lane " .. tostring(CONFIG.meleeLane))
  elseif cmd == "laneh" and v then
    CONFIG.laneH = v; layout(); recomputeGeometry()
  elseif cmd == "idlealpha" and v then
    CONFIG.idleAlpha = v; updateVisibility()
  elseif cmd == "alwaysshow" then
    CONFIG.hideNoTarget = not CONFIG.hideNoTarget; updateVisibility()
    print("|cff88ccffWL|r hide with no target: " .. tostring(CONFIG.hideNoTarget))
  elseif cmd == "gloss" then CONFIG.gloss = not CONFIG.gloss
  elseif cmd == "squarehaste" then
    CONFIG.squareHaste = not CONFIG.squareHaste
    print("|cff88ccffWL|r squareHaste " .. tostring(CONFIG.squareHaste))
  elseif cmd == "sync" then
    seedGenerator(GetTime())
    print("|cff88ccffWL|r plan regenerated from now")
  elseif cmd == "gcd" then
    local cs, cd = spellCD(SPELL.steady)
    local now = GetTime()
    if cs and cs > 0 then
      print(string.format("|cff88ccffWL|r GCD readable: %sms left of %sms",
        ms((cs + cd) - now), ms(cd)))
    else
      print("|cffff4444WL|r GCD not readable right now.")
      print("  If it never reads while you are mid-Steady, the instant")
      print("  window opens too early and will look far too wide.")
    end

  elseif cmd == "apis" then
    print("|cff88ccffWL|r options APIs on this client:")
    local function has(n, v) print(string.format("  %-42s %s", n, v and "yes" or "no")) end
    has("Settings", Settings)
    has("Settings.RegisterCanvasLayoutCategory",
        Settings and Settings.RegisterCanvasLayoutCategory)
    has("Settings.RegisterAddOnCategory",
        Settings and Settings.RegisterAddOnCategory)
    has("Settings.OpenToCategory", Settings and Settings.OpenToCategory)
    has("InterfaceOptions_AddCategory", InterfaceOptions_AddCategory)
    has("InterfaceOptionsFrame_OpenToCategory", InterfaceOptionsFrame_OpenToCategory)
    has("InterfaceOptionsFrame", InterfaceOptionsFrame)
    has("WeaveLineOptionsPanel built", WeaveLineOptionsPanel)
    has("category registered", WeaveLineOptionsCategory)
    if WeaveLineOptionsCategory then
      print("  category ID: " .. tostring(WeaveLineOptionsCategory.ID
        or (WeaveLineOptionsCategory.GetID and WeaveLineOptionsCategory:GetID())))
    end

  elseif cmd == "font" then
    print("|cff88ccffWL|r font candidates for '" .. tostring(CONFIG.fontFace) .. "':")
    local probe = rangeLabel
    local before = probe:GetFont()
    local lib = LSM()
    print("  LibSharedMedia: " .. (lib and "found" or "not installed"))
    if lib then
      local ok, n = pcall(function() return #lib:List("font") end)
      if ok then print("  fonts registered with LSM: " .. tostring(n)) end
    end
    local list = fontPaths(CONFIG.fontFace) or {}
    if #list == 0 then print("  (stock font, nothing to load)") end
    for _, cand in ipairs(list) do
      local ok = pcall(function() probe:SetFont(cand, 12, "OUTLINE") end)
      local cur = ok and probe:GetFont() or nil
      local hit = cur and cur:lower() == cand:lower()
      print(string.format("  %s %s", hit and "|cff5fd97fLOADED|r"
        or "|cffff4444 no   |r", cand))
    end
    pcall(function() probe:SetFont(before, CONFIG.rangeSize or 12, "OUTLINE") end)
    applyFont()

  elseif cmd == "options" or cmd == "config" then
    -- OpenToCategory wants the category ID, not the category object.
    -- Passing the table errors inside Blizzard_Settings.
    if WeaveLineWindowFrame then
      WeaveLineWindowFrame:Show()
      return
    end
    local cat = WeaveLineOptionsCategory
    local id  = cat and (cat.ID or (cat.GetID and cat:GetID()))
    local opened = false
    if id and Settings and Settings.OpenToCategory then
      opened = pcall(Settings.OpenToCategory, id)
    end
    if opened then
      -- done
    elseif InterfaceOptionsFrame_OpenToCategory then
      InterfaceOptionsFrame_OpenToCategory(WeaveLineOptionsPanel)
      InterfaceOptionsFrame_OpenToCategory(WeaveLineOptionsPanel)
    else
      print("|cff88ccffWL|r use Esc > Options > AddOns > WeaveLine")
    end

  elseif cmd == "check" then
    print(string.format("|cff88ccffWL|r eWS %.3f haste %.3f", ews(), haste()))
    print(string.format("  steady %sms  multi %sms  auto %sms  reload %sms  gap %sms",
      ms(steadyCast()), ms(multiCast()), ms(autoCast()), ms(reload()),
      ms(CONFIG.gcd - steadyCast())))
    print(string.format("  rotation %s  notes %d",
      currentRot().name, #state.plan))
    print(string.format("  gate %s  holding=%s  last stall %sms",
      state.gate and "armed" or "none", tostring(state.holding), ms(state.lastStall)))
    local tv = travelTime()
    print(string.format("  travel to melee %s  |  usable window %s",
      tv and (ms(tv) .. "ms one way") or "n/a",
      tv and (ms(math.max(0, (reload() - steadyCast()) - tv * 2)) .. "ms") or "n/a"))
    local gl, e = cycleLength(), ews()
    print(string.format("  grid %sms  (eWS %sms, measured %s, %+.1f%%)",
      ms(gl), ms(e),
      state.cycleLen and (ms(state.cycleLen) .. "ms") or "learning",
      (e > 0) and ((gl / e - 1) * 100) or 0))
    print(string.format("  last phase err %sms  gain %.2f  pending %sms  (lock %s)",
      ms(state.lastPhaseErr), CONFIG.phaseGain, ms(state.pending),
      tostring(CONFIG.phaseLock)))
    print(string.format("  multi cd %.1f  arcane cd %.1f",
      realCdLeft(SPELL.multi), realCdLeft(SPELL.arcane)))
    print(string.format("  raw (GCD-contaminated): multi %.1f  arcane %.1f",
      cdLeft(SPELL.multi), cdLeft(SPELL.arcane)))
  elseif cmd == "border" and v then
    CONFIG.border = v; layout()
    print("|cff88ccffWL|r border " .. v .. "px")
  elseif cmd == "flash" and v then
    CONFIG.impactMelee = v; CONFIG.impactRaptor = v * 1.6
  elseif cmd == "scale" and v then
    CONFIG.impactScale = v
    print("|cff88ccffWL|r impact swell " .. math.floor(v * 100) .. "%")
  elseif cmd == "peak" and v then
    CONFIG.impactPeak = v; print("|cff88ccffWL|r impact peak " .. v)
  elseif cmd == "pop" and v then
    CONFIG.impactPop = v; print("|cff88ccffWL|r border pop " .. v .. "px")
  elseif cmd == "punch" and v then
    CONFIG.impactScale = v
    print("|cff88ccffWL|r impact expansion " .. math.floor(v * 100) .. "%")
  elseif cmd == "idleheight" and v then
    CONFIG.idleHeight = v
    print("|cff88ccffWL|r impact flash " .. ms(v) .. "ms")
  elseif cmd == "testflash" then
    state.impactAt, state.impactDur, state.impactStrong =
      GetTime(), CONFIG.impactRaptor, true

  elseif cmd == "idle" then
    CONFIG.showIdle = not CONFIG.showIdle
    print("|cff88ccffWL|r idle GCD segments " .. (CONFIG.showIdle and "shown" or "hidden"))

  elseif cmd == "meleeprobe" then
    CONFIG.meleeUseAutoShot = not CONFIG.meleeUseAutoShot
    print("|cff88ccffWL|r auto-shot melee probe: " .. tostring(CONFIG.meleeUseAutoShot))
  elseif cmd == "textgap" and v then
    CONFIG.textGap = v; layout()

  elseif cmd == "trace" then
    local now = GetTime() - state.hold
    print(string.format("|cff88ccffWL|r notes near the line (hold %sms)",
      ms(state.hold)))
    for _, e in ipairs(state.plan) do
      local rel = e.t0 - now
      if rel > -2 and rel < 4 then
        print(string.format("   %+6sms  %-7s  %sms%s",
          ms(rel), e.kind, ms(e.t1 - e.t0),
          (state.gate and math.abs(e.t1 - state.gate) < 0.001) and "   <-- gate" or ""))
      end
    end

  elseif cmd == "gaps" then
    local n, worst = 0, 0
    for i = 2, #state.plan do
      local g = state.plan[i].t0 - state.plan[i-1].t1
      if g > 0.005 then
        n = n + 1
        if g > worst then worst = g end
        if n <= 5 then
          print(string.format("  gap %sms between %s and %s",
            ms(g), state.plan[i-1].kind, state.plan[i].kind))
        end
      end
    end
    print(string.format("|cff88ccffWL|r %d notes, %d time gaps, worst %sms",
      #state.plan, n, ms(worst)))

  elseif cmd == "range" then
    local u = "target"
    if not UnitExists(u) then
      print("|cff88ccffWL|r no target")
    else
      print(string.format("|cff88ccffWL|r state=%s  text=%s",
        tostring(rangeState()), rangeText()))
      print(string.format("  estimate %s  bracket %.0f-%.0f  dir %d  fix age %sms  speed %.1f",
        state.dist and string.format("%.2f yd", state.dist) or "n/a",
        state.probeLo, state.probeHi, state.moveDir,
        ms(GetTime() - state.fixAt),
        (GetUnitSpeed and GetUnitSpeed("player")) or 0))
      print(string.format("  wingclip=%s  autoshot-blocked=%s  ->melee=%s",
        tostring(wingClipInRange(u)), tostring(autoShotBlocked(u)),
        tostring(inMelee(u))))
      local parts = {}
      for _, r in ipairs(RANGE_LADDER) do
        parts[#parts+1] = string.format("%dyd=%s", r[1], tostring(itemInRange(r[2], u)))
      end
      print("  " .. table.concat(parts, "  "))
    end

  elseif cmd == "lock"   then holder:EnableMouse(false)
  elseif cmd == "unlock" then holder:EnableMouse(true)
  else
    print("|cff88ccffWL|r options | check | font | options | trace | gaps | range | idle | meleeprobe | textgap | border | flash | scale | peak | pop | punch | idleheight | testflash | sync | actual | laneh | idlealpha | alwaysshow | width | cycles | linepos | ticks | ghost | horizon | seps | sepwidth | pips | pipsize | casttick | castbar | fullbar | nowline | weavebar | slack | slackh | melee |  reach | runspeed | edgefade | deadzone | gain | cyclegain | bleed | regrid | estimate | gate | gatemax | phaselock | sepbright | sepoverhang | idlestyle | idlemin | gloss | squarehaste | lock | unlock")
  end
end
